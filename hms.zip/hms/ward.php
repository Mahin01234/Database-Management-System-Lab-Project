<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM ward WHERE ward_id = $id");
    if ($del) {
        header("Location: ward.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);
    }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['ward_id']);
    $ward_number = trim(mysqli_real_escape_string($conn, $_POST['ward_number']));
    $ward_type = trim(mysqli_real_escape_string($conn, $_POST['ward_type']));
    $floor = trim(mysqli_real_escape_string($conn, $_POST['floor']));
    $capacity = intval($_POST['capacity']);
    $current_occupancy = intval($_POST['current_occupancy']);
    $status = trim(mysqli_real_escape_string($conn, $_POST['status']));
    if (empty($ward_number) || empty($ward_type) || empty($floor) || $capacity <= 0) {
        $msg = "Please fill all required fields (Ward Number, Type, Floor, Capacity).";
    } else {
        if ($id == 0) {
            $sql = "INSERT INTO ward (ward_number, ward_type, floor, capacity, current_occupancy, status)
                    VALUES ('$ward_number', '$ward_type', '$floor', $capacity, $current_occupancy, '$status')";
        } else {
            $sql = "UPDATE ward SET
                    ward_number = '$ward_number',
                    ward_type = '$ward_type',
                    floor = '$floor',
                    capacity = $capacity,
                    current_occupancy = $current_occupancy,
                    status = '$status'
                    WHERE ward_id = $id";
        }
        if (mysqli_query($conn, $sql)) {
            header("Location: ward.php?save=ok");
            exit();
        } else {
            $msg = "Save failed: " . mysqli_error($conn);
        }
    }
}
$res = mysqli_query($conn, "SELECT * FROM ward ORDER BY ward_id ASC");
$wards = [];
if ($res && mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        $wards[] = $row;
    }
} else {
    if ($res === false) {
        $msg = "Fetch failed: " . mysqli_error($conn);
    }
}
$edit = null;
if (isset($_GET['edit']) && intval($_GET['edit']) > 0) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT * FROM ward WHERE ward_id = $eid");
    if ($q && mysqli_num_rows($q) > 0) {
        $edit = mysqli_fetch_assoc($q);
    } else {
        $msg = "Edit failed: " . mysqli_error($conn);
        $edit = null;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Wards</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .hint { font-size: 13px; color: #6c757d; margin-left: 5px; }
        .status-available { color: #28a745; font-weight: bold; }
        .status-full { color: #dc3545; font-weight: bold; }
        .status-maintenance { color: #ffc107; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h2>Wards</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">Ward saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">Ward deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <!-- ===== FORM ===== -->
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Ward' : 'Add New Ward'; ?></h3>
        <form method="POST">
            <input type="hidden" name="ward_id" value="<?php echo $edit ? $edit['ward_id'] : 0; ?>">
            <div class="form-group">
                <label>Ward Number <span class="req"></span></label>
                <input type="text" name="ward_number" 
                       value="<?php echo $edit ? htmlspecialchars($edit['ward_number']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Ward Type <span class="req"></span></label>
                <select name="ward_type" required>
                    <option value=""></option>
                    <option value="General" <?php echo ($edit && $edit['ward_type'] == 'General') ? 'selected' : ''; ?>>General</option>
                    <option value="Private" <?php echo ($edit && $edit['ward_type'] == 'Private') ? 'selected' : ''; ?>>Private</option>
                    <option value="ICU" <?php echo ($edit && $edit['ward_type'] == 'ICU') ? 'selected' : ''; ?>>ICU</option>
                    <option value="Emergency" <?php echo ($edit && $edit['ward_type'] == 'Emergency') ? 'selected' : ''; ?>>Emergency</option>
                    <option value="Maternity" <?php echo ($edit && $edit['ward_type'] == 'Maternity') ? 'selected' : ''; ?>>Maternity</option>
                </select>
            </div>
            <div class="form-group">
                <label>Floor <span class="req"></span></label>
                <input type="text" name="floor"
                       value="<?php echo $edit ? htmlspecialchars($edit['floor']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Capacity <span class="req"></span></label>
                <input type="number" name="capacity" 
                       value="<?php echo $edit ? $edit['capacity'] : ''; ?>" required min="1">
            </div>
            <div class="form-group">
                <label>Current Occupancy</label>
                <input type="number" name="current_occupancy" 
                       value="<?php echo $edit ? $edit['current_occupancy'] : ''; ?>" min="0">
                <span class="hint"></span>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Available" <?php echo ($edit && $edit['status'] == 'Available') ? 'selected' : ''; ?>>Available</option>
                    <option value="Full" <?php echo ($edit && $edit['status'] == 'Full') ? 'selected' : ''; ?>>Full</option>
                </select>
                <span class="hint"></span>
            </div>

            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="ward.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="toolbar">
        <h3>All Wards</h3>
        <a href="ward.php" class="btn btn-primary">Add New</a>
    </div>
    <?php if (count($wards) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ward Number</th>
                        <th>Type</th>
                        <th>Floor</th>
                        <th>Capacity</th>
                        <th>Occupancy</th>
                        <th>Status</th>
                        <th style="width:130px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($wards as $ward): ?>
                        <tr>
                            <td><?php echo $ward['ward_id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($ward['ward_number']); ?></strong></td>
                            <td><?php echo htmlspecialchars($ward['ward_type']); ?></td>
                            <td><?php echo htmlspecialchars($ward['floor']); ?></td>
                            <td><?php echo $ward['capacity']; ?></td>
                            <td><?php echo $ward['current_occupancy']; ?></td>
                            <td>
                                <?php
                                $status = $ward['status'] ?? 'N/A';
                                $status_class = '';
                                if ($status == 'Available') $status_class = 'status-available';
                                elseif ($status == 'Full') $status_class = 'status-full';
                                elseif ($status == 'Maintenance') $status_class = 'status-maintenance';
                                ?>
                                <span class="<?php echo $status_class; ?>"><?php echo htmlspecialchars($status); ?></span>
                            </td>
                            <td>
                                <div class="actions">
                                    <a href="ward.php?edit=<?php echo $ward['ward_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="ward.php?delete=<?php echo $ward['ward_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No wards found.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>