<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM doctor WHERE doctor_id = $id");
    if ($del) {
        header("Location: doctor.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);
    }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['doctor_id']);
    $name = trim(mysqli_real_escape_string($conn, $_POST['name']));
    $specialization = trim(mysqli_real_escape_string($conn, $_POST['specialization']));
    $dept_id = intval($_POST['dept_id']);
    $contact = trim(mysqli_real_escape_string($conn, $_POST['contact']));
    $email = trim(mysqli_real_escape_string($conn, $_POST['email']));
    $qualification = trim(mysqli_real_escape_string($conn, $_POST['qualification']));
    $experience = intval($_POST['experience_years']);
    $schedule = trim(mysqli_real_escape_string($conn, $_POST['schedule']));
    $fee = floatval($_POST['consultation_fee']);
    $availability = trim(mysqli_real_escape_string($conn, $_POST['availability']));
    if (empty($name) || empty($specialization) || $dept_id == 0 || empty($contact)) {
        $msg = "Please fill all required fields.";
    } else {
        if ($id == 0) {
            $sql = "INSERT INTO doctor (name, specialization, dept_id, contact, email, qualification, experience_years, schedule, consultation_fee, availability)
                    VALUES ('$name', '$specialization', $dept_id, '$contact', '$email', '$qualification', $experience, '$schedule', $fee, '$availability')";
        } else {
            $sql = "UPDATE doctor SET
                    name='$name',
                    specialization='$specialization',
                    dept_id=$dept_id,
                    contact='$contact',
                    email='$email',
                    qualification='$qualification',
                    experience_years=$experience,
                    schedule='$schedule',
                    consultation_fee=$fee,
                    availability='$availability'
                    WHERE doctor_id=$id";       }
        if (mysqli_query($conn, $sql)) {
            header("Location: doctor.php?save=ok");
            exit();
        } else {
            $msg = "Save failed: " . mysqli_error($conn);       }
    }
}
$res = mysqli_query($conn, "SELECT d.*, dept.name as dept_name 
                            FROM doctor d 
                            LEFT JOIN department dept ON d.dept_id = dept.dept_id 
                            ORDER BY d.doctor_id DESC");
$doctors = [];
while ($row = mysqli_fetch_assoc($res)) {
    $doctors[] = $row;}
$edit = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT * FROM doctor WHERE doctor_id = $eid");
    $edit = mysqli_fetch_assoc($q);}
$dept_res = mysqli_query($conn, "SELECT dept_id, name FROM department ORDER BY name");
$departments = [];
while ($d = mysqli_fetch_assoc($dept_res)) {
    $departments[] = $d;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Doctors</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Manage Doctors</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">Doctor saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">Doctor deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"><?php echo $msg; ?></div>
    <?php endif; ?>
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Doctor' : 'Add New Doctor'; ?></h3>
        <form method="POST">
            <input type="hidden" name="doctor_id" value="<?php echo $edit ? $edit['doctor_id'] : 0; ?>">
            <div class="form-group">
                <label>Full Name <span class="req">*</span></label>
                <input type="text" name="name" placeholder="e.g. Dr. Rahim Ahmed" value="<?php echo $edit ? htmlspecialchars($edit['name']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Specialization <span class="req">*</span></label>
                <input type="text" name="specialization" placeholder="e.g. Cardiologist" value="<?php echo $edit ? htmlspecialchars($edit['specialization']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Department <span class="req">*</span></label>
                <select name="dept_id" required>
                    <option value="">— Select Department —</option>
                    <?php foreach ($departments as $dept): ?>
                        <option value="<?php echo $dept['dept_id']; ?>" <?php echo ($edit && $edit['dept_id'] == $dept['dept_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($departments)): ?>
                    <span class="hint" style="color:red;">No departments found. Please add departments first.</span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>Contact <span class="req">*</span></label>
                <input type="text" name="contact" placeholder="e.g. 01811111111" value="<?php echo $edit ? htmlspecialchars($edit['contact']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="e.g. doctor@hospital.com" value="<?php echo $edit ? htmlspecialchars($edit['email']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Qualification</label>
                <input type="text" name="qualification" placeholder="e.g. MBBS, FCPS" value="<?php echo $edit ? htmlspecialchars($edit['qualification']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Experience (Years)</label>
                <input type="number" name="experience_years" placeholder="e.g. 12" value="<?php echo $edit ? $edit['experience_years'] : ''; ?>" min="0">
            </div>
            <div class="form-group">
                <label>Schedule</label>
                <input type="text" name="schedule" placeholder="e.g. 9:00 AM - 5:00 PM" value="<?php echo $edit ? htmlspecialchars($edit['schedule']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Consultation Fee</label>
                <input type="number" step="0.01" name="consultation_fee" placeholder="e.g. 1000.00" value="<?php echo $edit ? $edit['consultation_fee'] : ''; ?>" min="0">
            </div>
            <div class="form-group">
                <label>Availability</label>
                <select name="availability">
                    <option value="Available" <?php echo ($edit && $edit['availability'] == 'Available') ? 'selected' : ''; ?>>Available</option>
                    <option value="On Leave" <?php echo ($edit && $edit['availability'] == 'On Leave') ? 'selected' : ''; ?>>On Leave</option>
                    <option value="Busy" <?php echo ($edit && $edit['availability'] == 'Busy') ? 'selected' : ''; ?>>Busy</option>
                </select>
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="doctor.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="toolbar">
        <h3>All Doctors</h3>
        <a href="doctor.php" class="btn btn-primary"> Add New</a>
    </div>
    <?php if (count($doctors) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Specialization</th>
                        <th>Department</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>Qualification</th>
                        <th>Experience</th>
                        <th>Schedule</th>
                        <th>Fee</th>
                        <th>Availability</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($doctors as $d): ?>
                        <tr>
                            <td><?php echo $d['doctor_id']; ?></td>
                            <td><?php echo htmlspecialchars($d['name']); ?></td>
                            <td><?php echo htmlspecialchars($d['specialization']); ?></td>
                            <td><?php echo htmlspecialchars($d['dept_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($d['contact']); ?></td>
                            <td><?php echo htmlspecialchars($d['email']); ?></td>
                            <td><?php echo htmlspecialchars($d['qualification']); ?></td>
                            <td><?php echo $d['experience_years']; ?></td>
                            <td><?php echo htmlspecialchars($d['schedule']); ?></td>
                            <td><?php echo number_format($d['consultation_fee'], 2); ?></td>
                            <td>
                                <span style="color: <?php echo ($d['availability'] == 'Available') ? 'green' : (($d['availability'] == 'On Leave') ? 'orange' : 'red'); ?>;">
                                    <?php echo $d['availability']; ?>
                                </span>
                            </td>
                            <td>
                                <div class="actions">
                                    <a href="doctor.php?edit=<?php echo $d['doctor_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="doctor.php?delete=<?php echo $d['doctor_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No doctors found. Add one using the form above.</div>
    <?php endif; ?>

    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>