<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM staff WHERE staff_id = $id AND role = 'Nurse'");
    if ($del) {
        header("Location: nurse.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);
    }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['staff_id']);
    $name = trim(mysqli_real_escape_string($conn, $_POST['name']));
    $role = 'Nurse';
    $dept_id = intval($_POST['dept_id']);
    $contact = trim(mysqli_real_escape_string($conn, $_POST['contact']));
    $email = trim(mysqli_real_escape_string($conn, $_POST['email']));
    $shift = trim(mysqli_real_escape_string($conn, $_POST['shift_time']));
    $joining = trim(mysqli_real_escape_string($conn, $_POST['joining_date']));
    $salary = floatval($_POST['salary']);
    $status = trim(mysqli_real_escape_string($conn, $_POST['status']));
    if ($salary < 0) {
        $msg = "Salary cannot be negative. Please enter a valid amount.";
    } elseif (empty($name) || $dept_id == 0 || empty($contact) || empty($joining)) {
        $msg = "Please fill all required fields (Name, Department, Contact, Joining Date).";
    } else {
        if ($id == 0) {
            $sql = "INSERT INTO staff (name, role, dept_id, contact, email, shift_time, joining_date, salary, status)
                    VALUES ('$name', '$role', $dept_id, '$contact', '$email', '$shift', '$joining', $salary, '$status')";
        } else {
            $sql = "UPDATE staff SET
                    name = '$name',
                    dept_id = $dept_id,
                    contact = '$contact',
                    email = '$email',
                    shift_time = '$shift',
                    joining_date = '$joining',
                    salary = $salary,
                    status = '$status'
                    WHERE staff_id = $id AND role = 'Nurse'";
        }
        if (mysqli_query($conn, $sql)) {
            header("Location: nurse.php?save=ok");
            exit();
        } else {
            $msg = "Save failed: " . mysqli_error($conn);
        }
    }
}
$res = mysqli_query($conn, "SELECT s.*, d.name AS dept_name 
                            FROM staff s
                            LEFT JOIN department d ON s.dept_id = d.dept_id
                            WHERE s.role = 'Nurse'
                            ORDER BY s.staff_id ASC");
$nurses = [];
if ($res && mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        $nurses[] = $row;
    }
} else {
    if ($res === false) {
        $msg = "Fetch failed: " . mysqli_error($conn);
    }
}
$edit = null;
if (isset($_GET['edit']) && intval($_GET['edit']) > 0) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT * FROM staff WHERE staff_id = $eid AND role = 'Nurse'");
    if ($q && mysqli_num_rows($q) > 0) {
        $edit = mysqli_fetch_assoc($q);
    } else {
        $msg = "Edit failed: Record not found or not a Nurse.";
        $edit = null;
    }
}
$dept_res = mysqli_query($conn, "SELECT dept_id, name FROM department ORDER BY name");
$departments = [];
while ($d = mysqli_fetch_assoc($dept_res)) {
    $departments[] = $d;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Nurses</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .hint { font-size: 13px; color: #6c757d; margin-left: 5px; }
        .status-active { color: #28a745; font-weight: bold; }
        .status-inactive { color: #dc3545; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h2>Manage Nurses</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">Nurse saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success"> Nurse deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"> <?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <!-- ===== FORM ===== -->
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Nurse' : 'Add New Nurse'; ?></h3>
        <form method="POST">
            <input type="hidden" name="staff_id" value="<?php echo $edit ? $edit['staff_id'] : 0; ?>">
            <input type="hidden" name="role" value="Nurse">
            <div class="form-group">
                <label>Full Name <span class="req"></span></label>
                <input type="text" name="name" 
                       value="<?php echo $edit ? htmlspecialchars($edit['name']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Department <span class="req"></span></label>
                <select name="dept_id" required>
                    <option value=""></option>
                    <?php foreach ($departments as $dept): ?>
                        <option value="<?php echo $dept['dept_id']; ?>" 
                            <?php echo ($edit && $edit['dept_id'] == $dept['dept_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($departments)): ?>
                    <span class="hint" style="color:red;">No departments.</span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>Contact <span class="req"></span></label>
                <input type="text" name="contact" 
                       value="<?php echo $edit ? htmlspecialchars($edit['contact']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" 
                       value="<?php echo $edit ? htmlspecialchars($edit['email']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Shift Time</label>
                <select name="shift_time">
                    <option value="Morning" <?php echo ($edit && $edit['shift_time'] == 'Morning') ? 'selected' : ''; ?>>Morning</option>
                    <option value="Evening" <?php echo ($edit && $edit['shift_time'] == 'Evening') ? 'selected' : ''; ?>>Evening</option>
                    <option value="Night" <?php echo ($edit && $edit['shift_time'] == 'Night') ? 'selected' : ''; ?>>Night</option>
                </select>
            </div>
            <div class="form-group">
                <label>Joining Date <span class="req"></span></label>
                <input type="date" name="joining_date" 
                       value="<?php echo $edit ? $edit['joining_date'] : date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label>Per day</label>
                <input type="number" step="500" name="salary" 
                       value="<?php echo $edit ? $edit['salary'] : ''; ?>" min="0">
                <span class="hint"></span>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Active" <?php echo ($edit && $edit['status'] == 'Active') ? 'selected' : ''; ?>>Active</option>
                    <option value="Inactive" <?php echo ($edit && $edit['status'] == 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="nurse.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <!-- ===== LIST ===== -->
    <div class="toolbar">
        <h3>All Nurses</h3>
        <a href="nurse.php" class="btn btn-primary">Add New</a>
    </div>
    <?php if (count($nurses) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Department</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>Shift</th>
                        <th>Joining</th>
                        <th>Per day</th>
                        <th>Status</th>
                        <th style="width:130px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($nurses as $n): ?>
                        <tr>
                            <td><?php echo $n['staff_id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($n['name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($n['dept_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($n['contact']); ?></td>
                            <td><?php echo htmlspecialchars($n['email']); ?></td>
                            <td><?php echo htmlspecialchars($n['shift_time']); ?></td>
                            <td><?php echo date('d-M-Y', strtotime($n['joining_date'])); ?></td>
                            <td><?php echo number_format($n['salary'], 2); ?></td>
                            <td>
                                <?php
                                $status_class = ($n['status'] == 'Active') ? 'status-active' : 'status-inactive';
                                ?>
                                <span class="<?php echo $status_class; ?>"><?php echo $n['status']; ?></span>
                            </td>
                            <td>
                                <div class="actions">
                                    <a href="nurse.php?edit=<?php echo $n['staff_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="nurse.php?delete=<?php echo $n['staff_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No nurses.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>