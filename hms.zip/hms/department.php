<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
// Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM department WHERE dept_id = $id");
    if ($del) {
        header("Location: department.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);   }
}
// Save / Update
if (isset($_POST['save'])) {
    $id = intval($_POST['dept_id']);
    $name = trim(mysqli_real_escape_string($conn, $_POST['name']));
    $head = intval($_POST['head_doctor']);
    $floor = trim(mysqli_real_escape_string($conn, $_POST['floor']));
    $contact = trim(mysqli_real_escape_string($conn, $_POST['contact']));
    $desc = trim(mysqli_real_escape_string($conn, $_POST['description']));

    if (empty($name) || empty($floor) || empty($contact) || $head < 1 || $head > 5) {
        $msg = "Please fill all required fields correctly.";
    } else {
        if ($id == 0) {
            $sql = "INSERT INTO department (name, head_doctor, floor, contact, description) VALUES ('$name', $head, '$floor', '$contact', '$desc')";
        } else {
            $sql = "UPDATE department SET name='$name', head_doctor=$head, floor='$floor', contact='$contact', description='$desc' WHERE dept_id=$id";
        }
        if (mysqli_query($conn, $sql)) {
            header("Location: department.php?save=ok");
            exit();
        } else {
            $msg = "Save failed: " . mysqli_error($conn);       }
    }
}
// Fetch all departments
$res = mysqli_query($conn, "SELECT * FROM department ORDER BY dept_id ASC");
$depts = [];
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $depts[] = $row;
    }
}
// Edit data
$edit = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT * FROM department WHERE dept_id = $eid");
    if ($q) {
        $edit = mysqli_fetch_assoc($q);  }
}
// Fetch doctors (ID 1-5)
$doc_res = mysqli_query($conn, "SELECT doctor_id, name FROM doctor WHERE doctor_id IN (1,2,3,4,5) ORDER BY doctor_id ASC");
$doctors = [];
if ($doc_res) {
    while ($d = mysqli_fetch_assoc($doc_res)) {
        $doctors[] = $d;  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Department</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Departments</h2>
    <?php if (isset($_GET['save']) && $_GET['save'] == 'ok'): ?>
        <div class="msg-success">Department saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del'] == 'ok'): ?>
        <div class="msg-success"> Department deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <!-- Form -->
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Department' : 'Add New Department'; ?></h3>
        <form method="POST">
            <input type="hidden" name="dept_id" value="<?php echo $edit ? $edit['dept_id'] : 0; ?>">
            <div class="form-group">
                <label>Name <span class="req"></span></label>
                <input type="text" name="name" value="<?php echo $edit ? htmlspecialchars($edit['name']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Doctor Name <span class="req"></span></label>
                <select name="head_doctor" required>
                    <option value=""></option>
                    <?php foreach ($doctors as $doc): ?>
                        <option value="<?php echo $doc['doctor_id']; ?>" <?php echo ($edit && $edit['head_doctor'] == $doc['doctor_id']) ? 'selected' : ''; ?>>
                            <?php echo $doc['doctor_id'] . " - " . htmlspecialchars($doc['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($doctors)): ?>
                    <span class="hint" style="color:red;">No doctors found.</span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>Floor <span class="req"></span></label>
                <input type="text" name="floor" value="<?php echo $edit ? htmlspecialchars($edit['floor']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Contact <span class="req"></span></label>
                <input type="text" name="contact" value="<?php echo $edit ? htmlspecialchars($edit['contact']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" rows="3"><?php echo $edit ? htmlspecialchars($edit['description']) : ''; ?></textarea>
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="department.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <!-- Table -->
    <div class="toolbar">
        <h3>All Departments</h3>
        <a href="department.php" class="btn btn-primary">Add New</a>
    </div>
    <?php if (count($depts) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Doctor Name</th>
                        <th>Floor</th>
                        <th>Contact</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($depts as $d): ?>
                        <tr>
                            <td><?php echo $d['dept_id']; ?></td>
                            <td><?php echo htmlspecialchars($d['name']); ?></td>
                            <td>
                                <?php
                                $doc_name = '';
                                foreach ($doctors as $doc) {
                                    if ($doc['doctor_id'] == $d['head_doctor']) {
                                        $doc_name = $doc['name'];
                                        break;                                   }                              }
                                echo $doc_name ? htmlspecialchars($doc_name) : 'Doctor ID: ' . $d['head_doctor'];
                                ?>
                            </td>
                            <td><?php echo htmlspecialchars($d['floor']); ?></td>
                            <td><?php echo htmlspecialchars($d['contact']); ?></td>
                            <td><?php echo htmlspecialchars($d['description']); ?></td>
                            <td>
                                <div class="action-column">
                                    <a href="department.php?edit=<?php echo $d['dept_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="department.php?delete=<?php echo $d['dept_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No departments found. Add one using the form above.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>