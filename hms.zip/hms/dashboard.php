<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();}
include "config.php";
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Hospital Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrap">
    <div class="topbar">
        <h1><span>Hospital Dashboard</span></h1>
        <div class="userbox">
            <span class="name"><span class="profile-avatar">👨‍⚕️</span><?php echo htmlspecialchars($_SESSION['name']); ?></span>
            <a href="?logout=1" class="logout" onclick="return confirm('Are you sure you want to logout?');">Logout</a>
        </div>
    </div>
    <div class="grid">
        <a href="ambulance_call.php"><span class="icon"></span><span class="label">Ambulance Call</span></a>
        <a href="analytics_dashboard.php"><span class="icon"></span><span class="label">Analytics Dashboard</span></a>
        <a href="appointment.php"><span class="icon"></span><span class="label">Appointment</span></a>
        <a href="bed.php"><span class="icon"></span><span class="label">Bed</span></a>
        <a href="billing.php"><span class="icon"></span><span class="label">Billing</span></a>
        <a href="blood_bank.php" class="menu-card"><span class="icon"></span><span class="label">Blood Bank</span></a>
        <a href="department.php"><span class="icon"></span><span class="label">Department</span></a>
        <a href="labtest.php"><span class="icon"></span><span class="label">Lab Test</span></a>
        <a href="medicalrecord.php"><span class="icon"></span><span class="label">Medical Record</span></a>
        <a href="operation.php"><span class="icon"></span><span class="label">Operation</span></a>
        <a href="patient.php"><span class="icon"></span><span class="label">Patient</span></a>
        <a href="pharmacy.php"><span class="icon"></span><span class="label">Pharmacy</span></a>
        <a href="prescription.php"><span class="icon"></span><span class="label">Prescription</span></a>
        <a href="ward.php" class="menu-card"><span class="icon"></span><span class="label">Ward</span></a>
        <a href="nurse.php" class="menu-card"><span class="icon"></span><span class="label">Nurses</span></a>
    </div>
</div>
</body>
</html>