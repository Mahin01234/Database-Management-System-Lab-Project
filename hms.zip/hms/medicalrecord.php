<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM medicalrecord WHERE record_id = $id");
    if ($del) {
        header("Location: medicalrecord.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);
    }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['record_id']);
    $patient_name = trim(mysqli_real_escape_string($conn, $_POST['patient_name']));
    $doctor = intval($_POST['doctor_id']);
    $diagnosis = trim(mysqli_real_escape_string($conn, $_POST['diagnosis']));
    $treatment = trim(mysqli_real_escape_string($conn, $_POST['treatment']));
    $notes = trim(mysqli_real_escape_string($conn, $_POST['notes']));
    $follow_up = !empty($_POST['follow_up_date']) ? trim(mysqli_real_escape_string($conn, $_POST['follow_up_date'])) : NULL;
    $status = trim(mysqli_real_escape_string($conn, $_POST['status']));

    if (empty($patient_name) || $doctor == 0 || empty($diagnosis)) {
        $msg = "Please enter patient name, select doctor, and enter diagnosis.";
    } else {
        $check = mysqli_query($conn, "SELECT patient_id FROM patient WHERE name = '$patient_name'");
        if (mysqli_num_rows($check) > 0) {
            $row = mysqli_fetch_assoc($check);
            $patient_id = $row['patient_id'];
        } else {
            $insert = mysqli_query($conn, "INSERT INTO patient (name, status, registration_date) 
                                           VALUES ('$patient_name', 'Active', NOW())");
            if ($insert) {
                $patient_id = mysqli_insert_id($conn);
            } else {
                $msg = "Failed to create new patient: " . mysqli_error($conn);
                $patient_id = 0;
            }
        }
        if ($patient_id > 0) {
            if ($id == 0) {
                $sql = "INSERT INTO medicalrecord (patient_id, doctor_id, diagnosis, treatment, notes, follow_up_date, status)
                        VALUES ($patient_id, $doctor, '$diagnosis', '$treatment', '$notes', " . ($follow_up ? "'$follow_up'" : "NULL") . ", '$status')";
            } else {
                $sql = "UPDATE medicalrecord SET
                        patient_id=$patient_id,
                        doctor_id=$doctor,
                        diagnosis='$diagnosis',
                        treatment='$treatment',
                        notes='$notes',
                        follow_up_date=" . ($follow_up ? "'$follow_up'" : "NULL") . ",
                        status='$status'
                        WHERE record_id=$id";
            }
            if (mysqli_query($conn, $sql)) {
                header("Location: medicalrecord.php?save=ok");
                exit();
            } else {
                $msg = "Save failed: " . mysqli_error($conn);
            }
        }
    }
}
$res = mysqli_query($conn, "SELECT m.record_id, m.patient_id, m.doctor_id, m.diagnosis, m.treatment, m.notes, m.follow_up_date, m.status,
                                   p.name as patient_name, d.name as doctor_name 
                            FROM medicalrecord m
                            LEFT JOIN patient p ON m.patient_id = p.patient_id
                            LEFT JOIN doctor d ON m.doctor_id = d.doctor_id
                            ORDER BY m.record_id ASC");
$records = [];
while ($row = mysqli_fetch_assoc($res)) {
    $records[] = $row;
}

$edit = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT m.*, p.name as patient_name 
                              FROM medicalrecord m
                              LEFT JOIN patient p ON m.patient_id = p.patient_id
                              WHERE m.record_id = $eid");
    $edit = mysqli_fetch_assoc($q);
}

$doc_res = mysqli_query($conn, "SELECT doctor_id, name FROM doctor ORDER BY name");
$doctors = [];
while ($d = mysqli_fetch_assoc($doc_res)) {
    $doctors[] = $d;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Medical Records</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .msg-success { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .msg-error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .form-box { background: #f8f9fc; padding: 20px; border-radius: 10px; margin-bottom: 30px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: inline-block; width: 180px; font-weight: bold; }
        .form-group input, .form-group select, .form-group textarea { width: 55%; padding: 8px; border: 1px solid #ccc; border-radius: 5px; }
        .req { color: red; }
        .btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; font-size: 14px; }
        .btn-success { background: #28a745; color: white; }
        .btn-warning { background: #ffc107; color: #212529; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn-primary { background: #007BFF; color: white; }
        .btn-sm { padding: 4px 10px; font-size: 13px; }
        .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #007BFF; color: white; white-space: nowrap; }
        .action-column { display: flex; flex-direction: column; gap: 4px; align-items: center; }
        .action-column a { padding: 2px 10px; font-size: 13px; white-space: nowrap; text-align: center; width: 100%; }
        .empty-state { padding: 20px; text-align: center; color: #6c757d; }
        .back-link { display: inline-block; margin-top: 20px; }
        .status-active { color: #007BFF; font-weight: bold; }
        .status-resolved { color: #28a745; font-weight: bold; }
        .status-chronic { color: #ffc107; font-weight: bold; }
        .status-followup { color: #dc3545; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h2>Medical Records</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">Medical record saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success"> Medical record deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Medical Record' : 'Add New Medical Record'; ?></h3>
        <form method="POST">
            <input type="hidden" name="record_id" value="<?php echo $edit ? $edit['record_id'] : 0; ?>">
            <div class="form-group">
                <label>Patient Name <span class="req"></span></label>
                <input type="text" name="patient_name" value="<?php echo $edit ? htmlspecialchars($edit['patient_name']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Doctor <span class="req"></span></label>
                <select name="doctor_id" required>
                    <option value=""></option>
                    <?php foreach ($doctors as $d): ?>
                        <option value="<?php echo $d['doctor_id']; ?>" <?php echo ($edit && $edit['doctor_id'] == $d['doctor_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($d['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Diagnosis <span class="req"></span></label>
                <input type="text" name="diagnosis" value="<?php echo $edit ? htmlspecialchars($edit['diagnosis']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Treatment</label>
                <input type="text" name="treatment" value="<?php echo $edit ? htmlspecialchars($edit['treatment']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Notes</label>
                <textarea name="notes" rows="3"><?php echo $edit ? htmlspecialchars($edit['notes']) : ''; ?></textarea>
            </div>
            <div class="form-group">
                <label>Follow-up Date</label>
                <input type="date" name="follow_up_date" value="<?php echo $edit && $edit['follow_up_date'] ? $edit['follow_up_date'] : ''; ?>">
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Active" <?php echo ($edit && $edit['status'] == 'Active') ? 'selected' : ''; ?>>Active</option>
                    <option value="Resolved" <?php echo ($edit && $edit['status'] == 'Resolved') ? 'selected' : ''; ?>>Resolved</option>
                    <option value="Chronic" <?php echo ($edit && $edit['status'] == 'Chronic') ? 'selected' : ''; ?>>Chronic</option>
                    <option value="Follow-up Required" <?php echo ($edit && $edit['status'] == 'Follow-up Required') ? 'selected' : ''; ?>>Follow-up Required</option>
                </select>
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="medicalrecord.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="toolbar">
        <h3>All Medical Records</h3>
        <a href="medicalrecord.php" class="btn btn-primary">Add New</a>
    </div>
    <?php if (count($records) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Diagnosis</th>
                        <th>Treatment</th>
                        <th>Notes</th>
                        <th>Follow-up</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($records as $r): ?>
                        <tr>
                            <td><?php echo $r['record_id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($r['patient_name'] ?? 'N/A'); ?></strong></td>
                            <td><?php echo htmlspecialchars($r['doctor_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($r['diagnosis']); ?></td>
                            <td><?php echo htmlspecialchars($r['treatment']); ?></td>
                            <td><?php echo htmlspecialchars($r['notes']); ?></td>
                            <td>
                                <?php
                                if (!empty($r['follow_up_date']) && $r['follow_up_date'] != '0000-00-00') {
                                    echo date('d-M-Y', strtotime($r['follow_up_date']));
                                } else {
                                    echo '<span style="color:#999;">N/A</span>';
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                $class = '';
                                if ($r['status'] == 'Active') $class = 'status-active';
                                elseif ($r['status'] == 'Resolved') $class = 'status-resolved';
                                elseif ($r['status'] == 'Chronic') $class = 'status-chronic';
                                elseif ($r['status'] == 'Follow-up Required') $class = 'status-followup';
                                ?>
                                <span class="<?php echo $class; ?>"><?php echo htmlspecialchars($r['status']); ?></span>
                            </td>
                            <td>
                                <div class="action-column">
                                    <a href="medicalrecord.php?edit=<?php echo $r['record_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="medicalrecord.php?delete=<?php echo $r['record_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No medical records found. Add one using the form above.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>