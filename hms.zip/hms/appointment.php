<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();   }
include "config.php";
$msg = "";
// Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM appointment WHERE appointment_id = $id");
    if ($del) {
        header("Location: appointment.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);     }
}
// Save / Update
if (isset($_POST['save'])) {
    $id = intval($_POST['appointment_id']);
    $patient_name = trim(mysqli_real_escape_string($conn, $_POST['patient_name']));
    $doctor = intval($_POST['doctor_id']);
    $date = trim(mysqli_real_escape_string($conn, $_POST['appointment_date']));
    $status = trim(mysqli_real_escape_string($conn, $_POST['status']));
    $notes = trim(mysqli_real_escape_string($conn, $_POST['notes'] ?? ''));
    if (empty($patient_name) || $doctor == 0 || empty($date)) {
        $msg = "Please enter patient name, select doctor and appointment date.";
    } else {
        $check = mysqli_query($conn, "SELECT patient_id FROM patient WHERE name = '$patient_name'");
        if (mysqli_num_rows($check) > 0) {
            $row = mysqli_fetch_assoc($check);
            $patient_id = $row['patient_id'];
        } else {
            $insert = mysqli_query($conn, "INSERT INTO patient (name, status, registration_date) 
                                           VALUES ('$patient_name', 'Active', NOW())");
            if ($insert) {
                $patient_id = mysqli_insert_id($conn);
            } else {
                $msg = "Failed to create new patient: " . mysqli_error($conn);
                $patient_id = 0;            }
        }
        if ($patient_id > 0) {
            if ($id == 0) {
                $sql = "INSERT INTO appointment (patient_id, doctor_id, appointment_date, status, notes)
                        VALUES ($patient_id, $doctor, '$date', '$status', '$notes')";
            } else {
                $sql = "UPDATE appointment SET
                        patient_id = $patient_id,
                        doctor_id = $doctor,
                        appointment_date = '$date',
                        status = '$status',
                        notes = '$notes'
                        WHERE appointment_id = $id";            }
            if (mysqli_query($conn, $sql)) {
                header("Location: appointment.php?save=ok");
                exit();
            } else {
                $msg = "Save failed: " . mysqli_error($conn);            }
        }
    }
}
// Fetch all appointments
$res = mysqli_query($conn, "SELECT a.*, p.name as patient_name, d.name as doctor_name 
                            FROM appointment a
                            LEFT JOIN patient p ON a.patient_id = p.patient_id
                            LEFT JOIN doctor d ON a.doctor_id = d.doctor_id
                            ORDER BY a.appointment_id ASC");
$appointments = [];
while ($row = mysqli_fetch_assoc($res)) {
    $appointments[] = $row;               }
// Edit data
$edit = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT a.*, p.name as patient_name 
                              FROM appointment a
                              LEFT JOIN patient p ON a.patient_id = p.patient_id
                              WHERE a.appointment_id = $eid");
    $edit = mysqli_fetch_assoc($q);          }
// Fetch doctors
$doc_res = mysqli_query($conn, "SELECT doctor_id, name FROM doctor ORDER BY name");
$doctors = [];
while ($d = mysqli_fetch_assoc($doc_res)) {
    $doctors[] = $d;   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Appointments</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">Appointment saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">Appointment deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <!-- Form -->
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Appointment' : 'Add New Appointment'; ?></h3>
        <form method="POST">
            <input type="hidden" name="appointment_id" value="<?php echo $edit ? $edit['appointment_id'] : 0; ?>">
            <div class="form-group">
                <label>Patient Name <span class="req"></span></label>
                <input type="text" name="patient_name" 
                       value="<?php echo $edit ? htmlspecialchars($edit['patient_name']) : ''; ?>" 
                       required autocomplete="off">
            </div>
            <div class="form-group">
                <label>Doctor <span class="req"></span></label>
                <select name="doctor_id" required>
                    <option value=""></option>
                    <?php foreach ($doctors as $d): ?>
                        <option value="<?php echo $d['doctor_id']; ?>" <?php echo ($edit && $edit['doctor_id'] == $d['doctor_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($d['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($doctors)): ?>
                    <span class="hint" style="color:red;">No doctors found.</span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>Date & Time <span class="req"></span></label>
                <input type="datetime-local" name="appointment_date" 
                       value="<?php echo $edit ? date('Y-m-d\TH:i', strtotime($edit['appointment_date'])) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Completed" <?php echo ($edit && $edit['status'] == 'Completed') ? 'selected' : ''; ?>>Completed</option>
                    <option value="Cancelled" <?php echo ($edit && $edit['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                </select>
            </div>
            <div class="form-group">
                <label>Notes</label>
                <textarea name="notes" rows="3"><?php echo ($edit && isset($edit['notes'])) ? htmlspecialchars($edit['notes']) : ''; ?></textarea>
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="appointment.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <!-- Table -->
    <div class="toolbar">
        <h3>All Appointments</h3>
        <a href="appointment.php" class="btn btn-primary">Add New</a>
    </div>
    <?php if (count($appointments) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Date & Time</th>
                        <th>Status</th>
                        <th>Notes</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($appointments as $a): ?>
                        <tr>
                            <td><?php echo $a['appointment_id']; ?></td>
                            <td><?php echo htmlspecialchars($a['patient_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($a['doctor_name'] ?? 'N/A'); ?></td>
                            <td><?php echo date('d-M-Y h:i A', strtotime($a['appointment_date'])); ?></td>
                            <td>
                                <?php
                                $status_class = '';
                                if ($a['status'] == 'Scheduled') $status_class = 'status-scheduled';
                                elseif ($a['status'] == 'Completed') $status_class = 'status-completed';
                                elseif ($a['status'] == 'Cancelled') $status_class = 'status-cancelled';
                                elseif ($a['status'] == 'No-Show') $status_class = 'status-noshow';
                                ?>
                                <span class="<?php echo $status_class; ?>"><?php echo $a['status']; ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($a['notes'] ?? ''); ?></td>
                            <td>
                                <div class="action-column">
                                    <a href="appointment.php?edit=<?php echo $a['appointment_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="appointment.php?delete=<?php echo $a['appointment_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No appointments found.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>