<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if (mysqli_query($conn, "DELETE FROM prescription WHERE prescription_id=$id")) {
        header("Location: prescription.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);
    }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['prescription_id']);
    $patient_name = mysqli_real_escape_string($conn, trim($_POST['patient_name']));
    $doctor_id = intval($_POST['doctor_id']);
    $prescription_date = mysqli_real_escape_string($conn, $_POST['prescription_date']);
    $diagnosis = mysqli_real_escape_string($conn, trim($_POST['diagnosis']));
    $notes = mysqli_real_escape_string($conn, trim($_POST['notes']));
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    if (empty($patient_name) || $doctor_id == 0 || empty($prescription_date) || empty($diagnosis)) {
        $msg = "Please fill all required fields.";
    } else {
        $check = mysqli_query($conn, "SELECT patient_id FROM patient WHERE name='$patient_name' LIMIT 1");
        if (mysqli_num_rows($check) > 0) {
            $row = mysqli_fetch_assoc($check);
            $patient_id = $row['patient_id'];
        } else {
            $insert = mysqli_query($conn, "INSERT INTO patient (name, status, registration_date) VALUES ('$patient_name', 'Active', NOW())");
            if ($insert) {
                $patient_id = mysqli_insert_id($conn);
            } else {
                $patient_id = 0;
                $msg = "Patient creation failed: " . mysqli_error($conn);
            }
        }
        if ($patient_id > 0) {
            if ($id == 0) {
                $sql = "INSERT INTO prescription (patient_id, doctor_id, prescription_date, diagnosis, notes, status)
                        VALUES ($patient_id, $doctor_id, '$prescription_date', '$diagnosis', '$notes', '$status')";
            } else {
                $sql = "UPDATE prescription SET patient_id=$patient_id, doctor_id=$doctor_id, prescription_date='$prescription_date', diagnosis='$diagnosis', notes='$notes', status='$status' WHERE prescription_id=$id";
            }
            if (mysqli_query($conn, $sql)) {
                header("Location: prescription.php?save=ok");
                exit();
            } else {
                $msg = "Save failed: " . mysqli_error($conn);
            }
        }
    }
}
$sql = "SELECT p.prescription_id, p.prescription_date, p.diagnosis, p.notes, p.status, 
               pat.name AS patient_name, doc.name AS doctor_name
        FROM prescription p
        LEFT JOIN patient pat ON p.patient_id = pat.patient_id
        LEFT JOIN doctor doc ON p.doctor_id = doc.doctor_id
        ORDER BY p.prescription_id ASC";
$res = mysqli_query($conn, $sql);
$prescriptions = [];
while ($res && $row = mysqli_fetch_assoc($res)) {
    $prescriptions[] = $row;
}
$edit = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT p.*, pat.name AS patient_name FROM prescription p LEFT JOIN patient pat ON p.patient_id = pat.patient_id WHERE p.prescription_id=$id");
    if ($q && mysqli_num_rows($q) > 0) {
        $edit = mysqli_fetch_assoc($q);
    }
}
$doc_res = mysqli_query($conn, "SELECT doctor_id, name FROM doctor ORDER BY name");
$doctors = [];
while ($doc_res && $d = mysqli_fetch_assoc($doc_res)) {
    $doctors[] = $d;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescriptions</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .msg-success { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .msg-error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .form-box { background: #f8f9fc; padding: 20px; border-radius: 10px; margin-bottom: 30px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: inline-block; width: 180px; font-weight: bold; }
        .form-group input, .form-group select, .form-group textarea { width: 55%; padding: 8px; border: 1px solid #ccc; border-radius: 5px; }
        .req { color: red; }
        .btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; font-size: 14px; }
        .btn-success { background: #28a745; color: white; }
        .btn-warning { background: #ffc107; color: #212529; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn-primary { background: #007BFF; color: white; }
        .btn-sm { padding: 4px 10px; font-size: 13px; }
        .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #007BFF; color: white; white-space: nowrap; }
        .action-column { display: flex; flex-direction: column; gap: 4px; align-items: center; }
        .action-column a { padding: 2px 10px; font-size: 13px; white-space: nowrap; text-align: center; width: 100%; }
        .empty-state { padding: 20px; text-align: center; color: #6c757d; }
        .back-link { display: inline-block; margin-top: 20px; }
        .status-continue { color: #28a745; font-weight: bold; }
        .status-completed { color: #007BFF; font-weight: bold; }
        .status-cancelled { color: #dc3545; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h2>Prescriptions</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">Prescription saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">Prescription deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Prescription' : 'Add New Prescription'; ?></h3>
        <form method="POST">
            <input type="hidden" name="prescription_id" value="<?php echo $edit ? $edit['prescription_id'] : 0; ?>">

            <div class="form-group">
                <label>Patient Name <span class="req"></span></label>
                <input type="text" name="patient_name" value="<?php echo $edit ? htmlspecialchars($edit['patient_name']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Doctor <span class="req"></span></label>
                <select name="doctor_id" required>
                    <option value=""></option>
                    <?php foreach ($doctors as $d): ?>
                        <option value="<?php echo $d['doctor_id']; ?>" <?php echo ($edit && $edit['doctor_id'] == $d['doctor_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($d['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Prescription Date <span class="req"></span></label>
                <input type="datetime-local" name="prescription_date" value="<?php echo $edit ? date('Y-m-d\TH:i', strtotime($edit['prescription_date'])) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Diagnosis <span class="req"></span></label>
                <input type="text" name="diagnosis" value="<?php echo $edit ? htmlspecialchars($edit['diagnosis']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Notes</label>
                <textarea name="notes" rows="3"><?php echo $edit ? htmlspecialchars($edit['notes']) : ''; ?></textarea>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Completed" <?php echo ($edit && $edit['status'] == 'Completed') ? 'selected' : ''; ?>>Completed</option>
                    <option value="Cancelled" <?php echo ($edit && $edit['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                </select>
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="prescription.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="toolbar">
        <h3>All Prescriptions</h3>
        <a href="prescription.php" class="btn btn-primary">Add New</a>
    </div>
    <?php if (count($prescriptions) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Date</th>
                        <th>Diagnosis</th>
                        <th>Notes</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($prescriptions as $p): ?>
                        <tr>
                            <td><?php echo $p['prescription_id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($p['patient_name'] ?? 'N/A'); ?></strong></td>
                            <td><?php echo htmlspecialchars($p['doctor_name'] ?? 'N/A'); ?></td>
                            <td><?php echo date('d-M-Y h:i A', strtotime($p['prescription_date'])); ?></td>
                            <td><?php echo htmlspecialchars($p['diagnosis']); ?></td>
                            <td><?php echo htmlspecialchars($p['notes']); ?></td>
                            <td>
                                <?php
                                $class = '';
                                if ($p['status'] == 'Continue') $class = 'status-continue';
                                elseif ($p['status'] == 'Completed') $class = 'status-completed';
                                elseif ($p['status'] == 'Cancelled') $class = 'status-cancelled';
                                ?>
                                <span class="<?php echo $class; ?>"><?php echo htmlspecialchars($p['status']); ?></span>
                            </td>
                            <td>
                                <div class="action-column">
                                    <a href="prescription.php?edit=<?php echo $p['prescription_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="prescription.php?delete=<?php echo $p['prescription_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No prescriptions found. Add one using the form above.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>