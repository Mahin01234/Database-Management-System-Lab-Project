<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include "config.php"; 
$message = "";
if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());   
}
if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    if (!preg_match("/^[a-zA-Z]+$/", $username)) {
        $message = "Username can only contain letters (A-Z or a-z)!";
    } else {
        $sql = "SELECT user_id, username, name, password, role 
                FROM users 
                WHERE BINARY username = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if ($row = mysqli_fetch_assoc($result)) {
                if (password_verify($password, $row['password'])) {
                    $_SESSION['user_id'] = $row['user_id'];
                    $_SESSION['username'] = $row['username'];
                    $_SESSION['name'] = $row['name'];
                    $_SESSION['role'] = $row['role'];
                    header("Location: dashboard.php");
                    exit();
                } else {
                    $message = "Wrong Username or Password!";  
                }
            } else {
                $message = "Wrong Username or Password!";
            }
            mysqli_stmt_close($stmt);
        } else {
            die("Prepare Failed: " . mysqli_error($conn));   
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Hospital Management System - Login</title>
    <link rel="stylesheet" href="style.css">
    <style>

        .login-page {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
      
            background: linear-gradient(135deg, rgba(0, 51, 102, 0.85), rgba(0, 123, 255, 0.75)),
                        url('https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=1600') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .login-page .login-box {
            text-align: center;
            background: rgba(255, 255, 255, 0.95);
            padding: 45px 55px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
            max-width: 500px;
            width: 90%;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: fadeInUp 0.8s ease;
        }

    
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-page .login-box h2 {
            font-size: 32px;
            color: #003366;
            border-bottom: none;
            padding-bottom: 0;
            margin-bottom: 5px;
            letter-spacing: 1px;
        }

        .login-page .login-box h2 span {
            color: #003366;
        }

        .login-page .login-box h3 {
            font-size: 26px;
            color: #003366;
            margin-top: 0;
            margin-bottom: 25px;
            font-weight: 600;
        }

        .login-page .login-box .logo-icon {
            font-size: 60px;
            display: block;
            margin-bottom: 10px;
        }

        .login-page .login-box label {
            font-size: 18px;
            font-weight: 600;
            color: #003366;
            display: inline-block;
            width: 120px;
            text-align: right;
            margin-right: 12px;
        }

        .login-page .login-box input[type="text"],
        .login-page .login-box input[type="password"] {
            font-size: 20px;
            padding: 10px 14px;
            border: 2px solid #dce1e8;
            border-radius: 10px;
            width: 200px;
            margin-bottom: 18px;
            box-sizing: border-box;
            transition: 0.3s;
            background: #f8faff;
        }

        .login-page .login-box input[type="text"]:focus,
        .login-page .login-box input[type="password"]:focus {
            border-color: #007BFF;
            outline: none;
            box-shadow: 0 0 0 4px rgba(0, 123, 255, 0.15);
            background: #ffffff;
        }

        .login-page .login-box button {
            font-size: 22px;
            font-weight: 700;
            background: linear-gradient(135deg, #003366, #007BFF);
            color: white;
            border: none;
            padding: 12px 50px;
            border-radius: 50px;
            cursor: pointer;
            margin-top: 10px;
            transition: 0.3s;
            letter-spacing: 1px;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.3);
        }

        .login-page .login-box button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 123, 255, 0.5);
            background: linear-gradient(135deg, #001a4d, #0056b3);
        }

        .login-page .login-box .error {
            font-size: 18px;
            color: #dc3545;
            font-weight: 600;
            margin-top: 15px;
            background: #f8d7da;
            padding: 10px;
            border-radius: 10px;
            border: 1px solid #f5c6cb;
        }

        .login-page .login-box .form-row {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 8px;
            flex-wrap: wrap;
        }

        .login-page .login-box .link {
            margin-top: 22px;
            font-size: 17px;
            color: #495057;
        }

        .login-page .login-box .link a {
            color: #007BFF;
            text-decoration: none;
            font-weight: 600;
            transition: 0.3s;
        }

        .login-page .login-box .link a:hover {
            color: #003366;
            text-decoration: underline;
        }

    
        .login-page .login-box .credit {
            margin-top: 18px;
            font-size: 13px;
            color: #aab4d6;
        }


        @media (max-width: 640px) {
            .login-page .login-box {
                padding: 30px 25px;
            }
            .login-page .login-box h2 {
                font-size: 24px;
            }
            .login-page .login-box h3 {
                font-size: 22px;
            }
            .login-page .login-box label {
                display: block;
                text-align: center;
                width: auto;
                margin-right: 0;
                margin-bottom: 3px;
            }
            .login-page .login-box input[type="text"],
            .login-page .login-box input[type="password"] {
                width: 100%;
                font-size: 18px;
            }
            .login-page .login-box .form-row {
                flex-direction: column;
                align-items: stretch;
            }
            .login-page .login-box button {
                width: 100%;
                font-size: 20px;
                padding: 12px;
            }
        }

        @media (max-width: 400px) {
            .login-page .login-box {
                padding: 20px 15px;
            }
            .login-page .login-box h2 {
                font-size: 20px;
            }
            .login-page .login-box .logo-icon {
                font-size: 40px;
            }
        }
    </style>
</head>
<body class="login-page"> 
    <div class="login-box">
 
        <span class="logo-icon"></span>
        <h2>Hospital <span>Management</span></h2>
        <h3>Welcome Back</h3>
        
        <?php if (!empty($message)): ?>
            <p class="error"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-row">
                <label>Username:</label>
                <input type="text" name="username" pattern="[A-Za-z]+" 
                       title="Only letters allowed" required>
            </div>
            <div class="form-row">
                <label>Password:</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" name="login">Login</button>
        </form>
        
        <div class="link">
            Don't have an account? <a href="register.php">Register here</a>
        </div>
     
    </div>
</body>
</html>

