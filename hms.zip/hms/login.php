<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include "config.php"; 
$message = "";
if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());   }
if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    if (!preg_match("/^[a-zA-Z]+$/", $username)) {
        $message = "Username can only contain letters (A-Z or a-z)!";
    } else {
        $sql = "SELECT user_id, username, name, password, role 
                FROM users 
                WHERE BINARY username = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if ($row = mysqli_fetch_assoc($result)) {
                if (password_verify($password, $row['password'])) {
                    $_SESSION['user_id'] = $row['user_id'];
                    $_SESSION['username'] = $row['username'];
                    $_SESSION['name'] = $row['name'];
                    $_SESSION['role'] = $row['role'];
                    header("Location: dashboard.php");
                    exit();
                } else {
                    $message = "Wrong Username or Password!";  }
            } else {
                $message = "Wrong Username or Password!";
            }
            mysqli_stmt_close($stmt);
        } else {
            die("Prepare Failed: " . mysqli_error($conn));   }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Hospital Management System - Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="login-page"> 
    <div class="login-box">
        <h2>Hospital Management System</h2>
        <h3>Login</h3>
        <?php if (!empty($message)): ?>
            <p class="error"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>
        <form method="POST">
            <div class="form-row">
                <label>Username:</label>
                <input type="text" name="username" pattern="[A-Za-z]+" 
                       title="Only letters allowed" required>
            </div>
            <div class="form-row">
                <label>Password:</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" name="login">Login</button>
        </form>
        <div class="link">
            Don't have an account? <a href="register.php">Register here</a>
        </div>
    </div>
</body>
</html>