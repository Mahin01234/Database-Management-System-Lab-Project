<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM patient WHERE patient_id = $id");
    if ($del) {
        header("Location: patient.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);
    }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['patient_id']);
    $name = trim(mysqli_real_escape_string($conn, $_POST['name']));
    $dob = trim(mysqli_real_escape_string($conn, $_POST['date_of_birth']));
    $gender = trim(mysqli_real_escape_string($conn, $_POST['gender']));
    $contact = trim(mysqli_real_escape_string($conn, $_POST['contact']));
    $email = trim(mysqli_real_escape_string($conn, $_POST['email']));
    $address = trim(mysqli_real_escape_string($conn, $_POST['address']));
    $blood = trim(mysqli_real_escape_string($conn, $_POST['blood_group']));
    $history = trim(mysqli_real_escape_string($conn, $_POST['medical_history']));
    $emergency = trim(mysqli_real_escape_string($conn, $_POST['emergency_contact']));
    $status = trim(mysqli_real_escape_string($conn, $_POST['status']));
    if (empty($name) || empty($dob) || empty($gender) || empty($contact)) {
        $msg = "Please fill all required fields (Name, DOB, Gender, Contact).";
    } else {
        if ($id == 0) {
            $sql = "INSERT INTO patient (name, date_of_birth, gender, contact, email, address, blood_group, medical_history, emergency_contact, status)
                    VALUES ('$name', '$dob', '$gender', '$contact', '$email', '$address', '$blood', '$history', '$emergency', '$status')";
        } else {
            $sql = "UPDATE patient SET
                    name='$name',
                    date_of_birth='$dob',
                    gender='$gender',
                    contact='$contact',
                    email='$email',
                    address='$address',
                    blood_group='$blood',
                    medical_history='$history',
                    emergency_contact='$emergency',
                    status='$status'
                    WHERE patient_id=$id";
        }
        if (mysqli_query($conn, $sql)) {
            header("Location: patient.php?save=ok");
            exit();
        } else {
            $msg = "Save failed: " . mysqli_error($conn);
        }
    }
}
$res = mysqli_query($conn, "SELECT * FROM patient ORDER BY patient_id ASC");
$patients = [];
while ($row = mysqli_fetch_assoc($res)) {
    $patients[] = $row;
}
$edit = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT * FROM patient WHERE patient_id = $eid");
    if ($q) {
        $edit = mysqli_fetch_assoc($q);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Patients</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .msg-success { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .msg-error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .form-box { background: #f8f9fc; padding: 20px; border-radius: 10px; margin-bottom: 30px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: inline-block; width: 180px; font-weight: bold; }
        .form-group input, .form-group select, .form-group textarea { width: 55%; padding: 8px; border: 1px solid #ccc; border-radius: 5px; }
        .req { color: red; }
        .btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; font-size: 14px; }
        .btn-success { background: #28a745; color: white; }
        .btn-warning { background: #ffc107; color: #212529; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn-primary { background: #007BFF; color: white; }
        .btn-sm { padding: 4px 10px; font-size: 13px; }
        .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #007BFF; color: white; white-space: nowrap; }
        .action-column { display: flex; flex-direction: column; gap: 4px; align-items: center; }
        .action-column a { padding: 2px 10px; font-size: 13px; white-space: nowrap; text-align: center; width: 100%; }
        .empty-state { padding: 20px; text-align: center; color: #6c757d; }
        .back-link { display: inline-block; margin-top: 20px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Patients</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">Patient saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">Patient deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Patient' : 'Add New Patient'; ?></h3>
        <form method="POST">
            <input type="hidden" name="patient_id" value="<?php echo $edit ? $edit['patient_id'] : 0; ?>">
            <div class="form-group">
                <label>Full Name <span class="req"></span></label>
                <input type="text" name="name" value="<?php echo $edit ? htmlspecialchars($edit['name']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Date of Birth <span class="req"></span></label>
                <input type="date" name="date_of_birth" value="<?php echo $edit ? $edit['date_of_birth'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Gender <span class="req"></span></label>
                <select name="gender" required>
                    <option value=""></option>
                    <option value="Male" <?php echo ($edit && $edit['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                    <option value="Female" <?php echo ($edit && $edit['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                    <option value="Other" <?php echo ($edit && $edit['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                </select>
            </div>
            <div class="form-group">
                <label>Contact <span class="req"></span></label>
                <input type="text" name="contact" value="<?php echo $edit ? htmlspecialchars($edit['contact']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" value="<?php echo $edit ? htmlspecialchars($edit['email']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Address</label>
                <input type="text" name="address" value="<?php echo $edit ? htmlspecialchars($edit['address']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Blood Group</label>
                <select name="blood_group">
                    <option value=""></option>
                    <option value="A+" <?php echo ($edit && $edit['blood_group'] == 'A+') ? 'selected' : ''; ?>>A+</option>
                    <option value="A-" <?php echo ($edit && $edit['blood_group'] == 'A-') ? 'selected' : ''; ?>>A-</option>
                    <option value="B+" <?php echo ($edit && $edit['blood_group'] == 'B+') ? 'selected' : ''; ?>>B+</option>
                    <option value="B-" <?php echo ($edit && $edit['blood_group'] == 'B-') ? 'selected' : ''; ?>>B-</option>
                    <option value="AB+" <?php echo ($edit && $edit['blood_group'] == 'AB+') ? 'selected' : ''; ?>>AB+</option>
                    <option value="AB-" <?php echo ($edit && $edit['blood_group'] == 'AB-') ? 'selected' : ''; ?>>AB-</option>
                    <option value="O+" <?php echo ($edit && $edit['blood_group'] == 'O+') ? 'selected' : ''; ?>>O+</option>
                    <option value="O-" <?php echo ($edit && $edit['blood_group'] == 'O-') ? 'selected' : ''; ?>>O-</option>
                </select>
            </div>
            <div class="form-group">
                <label>Medical History</label>
                <textarea name="medical_history" rows="2"><?php echo $edit ? htmlspecialchars($edit['medical_history']) : ''; ?></textarea>
            </div>
            <div class="form-group">
                <label>Emergency Contact</label>
                <input type="text" name="emergency_contact" value="<?php echo $edit ? htmlspecialchars($edit['emergency_contact']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Active" <?php echo ($edit && $edit['status'] == 'Active') ? 'selected' : ''; ?>>Active</option>
                    <!-- <option value="Inactive" <?php echo ($edit && $edit['status'] == 'Inactive') ? 'selected' : ''; ?>>Inactive</option> -->
                    <option value="Discharged" <?php echo ($edit && $edit['status'] == 'Discharged') ? 'selected' : ''; ?>>Discharged</option>
                </select>
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="patient.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="toolbar">
        <h3>All Patients</h3>
        <a href="patient.php" class="btn btn-primary">Add New</a>
    </div>
    <?php if (count($patients) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>DOB</th>
                        <th>Gender</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Blood</th>
                        <th>History</th>
                        <th>Emergency</th>
                        <th>Status</th>
                        <th>Reg. Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($patients as $p): ?>
                        <tr>
                            <td><?php echo $p['patient_id']; ?></td>
                            <td><?php echo htmlspecialchars($p['name']); ?></td>
                            <td>
                                <?php
                                $dob = $p['date_of_birth'];
                                if (!empty($dob) && $dob != '0000-00-00') {
                                    echo date('d-M-Y', strtotime($dob));
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                            <td><?php echo $p['gender']; ?></td>
                            <td><?php echo htmlspecialchars($p['contact']); ?></td>
                            <td><?php echo htmlspecialchars($p['email']); ?></td>
                            <td><?php echo htmlspecialchars($p['address']); ?></td>
                            <td><?php echo $p['blood_group']; ?></td>
                            <td><?php echo htmlspecialchars($p['medical_history']); ?></td>
                            <td><?php echo htmlspecialchars($p['emergency_contact']); ?></td>
                            <td>
                                <?php
                                $color = ($p['status'] == 'Active') ? 'green' : (($p['status'] == 'Inactive') ? 'orange' : 'red');
                                ?>
                                <span style="color: <?php echo $color; ?>; font-weight: bold;">
                                    <?php echo $p['status']; ?>
                                </span>
                            </td>
                            <td><?php echo date('d-M-Y', strtotime($p['registration_date'])); ?></td>
                            <td>
                                <div class="action-column">
                                    <a href="patient.php?edit=<?php echo $p['patient_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="patient.php?delete=<?php echo $p['patient_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No patients found. Add one using the form above.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>