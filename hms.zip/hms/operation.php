<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM operation WHERE op_id = $id");
    if ($del) {
        header("Location: operation.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);
    }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['op_id']);
    $patient_name = trim(mysqli_real_escape_string($conn, $_POST['patient_name']));
    $doctor_id = intval($_POST['doctor_id']);
    $op_date = trim(mysqli_real_escape_string($conn, $_POST['operation_date']));
    $op_type = trim(mysqli_real_escape_string($conn, $_POST['operation_type']));
    $room = trim(mysqli_real_escape_string($conn, $_POST['room']));
    $status = trim(mysqli_real_escape_string($conn, $_POST['status']));
    $notes = trim(mysqli_real_escape_string($conn, $_POST['notes']));
    if (empty($patient_name) || $doctor_id == 0 || empty($op_date) || empty($op_type)) {
        $msg = "Please enter patient name, select doctor, operation date and type.";
    } else {
        $check = mysqli_query($conn, "SELECT patient_id FROM patient WHERE name = '$patient_name'");
        if (mysqli_num_rows($check) > 0) {
            $row = mysqli_fetch_assoc($check);
            $patient_id = $row['patient_id'];
        } else {
            // Create new patient
            $insert = mysqli_query($conn, "INSERT INTO patient (name, status, registration_date) 
                                           VALUES ('$patient_name', 'Active', NOW())");
            if ($insert) {
                $patient_id = mysqli_insert_id($conn);
            } else {
                $msg = "Failed to create new patient: " . mysqli_error($conn);
                $patient_id = 0;
            }
        }
        if ($patient_id > 0) {
            if ($id == 0) {
                $sql = "INSERT INTO operation (patient_id, doctor_id, operation_date, operation_type, room, status, notes)
                        VALUES ($patient_id, $doctor_id, '$op_date', '$op_type', '$room', '$status', '$notes')";
            } else {
                $sql = "UPDATE operation SET
                        patient_id = $patient_id,
                        doctor_id = $doctor_id,
                        operation_date = '$op_date',
                        operation_type = '$op_type',
                        room = '$room',
                        status = '$status',
                        notes = '$notes'
                        WHERE op_id = $id";
            }

            if (mysqli_query($conn, $sql)) {
                header("Location: operation.php?save=ok");
                exit();
            } else {
                $msg = "Save failed: " . mysqli_error($conn);
            }
        }
    }
}
$res = mysqli_query($conn, "SELECT o.*, p.name AS patient_name, d.name AS doctor_name 
                            FROM operation o
                            LEFT JOIN patient p ON o.patient_id = p.patient_id
                            LEFT JOIN doctor d ON o.doctor_id = d.doctor_id
                            ORDER BY o.op_id DESC");

$operations = [];
if ($res && mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        $operations[] = $row;
    }
} else {
    if ($res === false) {
        $msg = "Fetch failed: " . mysqli_error($conn);
    }
}
$edit = null;
if (isset($_GET['edit']) && intval($_GET['edit']) > 0) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT o.*, p.name AS patient_name 
                              FROM operation o
                              LEFT JOIN patient p ON o.patient_id = p.patient_id
                              WHERE o.op_id = $eid");
    if ($q && mysqli_num_rows($q) > 0) {
        $edit = mysqli_fetch_assoc($q);
    } else {
        $msg = "Edit failed: " . mysqli_error($conn);
        $edit = null;
    }
}
$doc_res = mysqli_query($conn, "SELECT doctor_id, name FROM doctor ORDER BY name");
$doctors = [];
while ($d = mysqli_fetch_assoc($doc_res)) {
    $doctors[] = $d;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Operations</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .hint { font-size: 13px; color: #6c757d; margin-left: 5px; }
        .status-scheduled { color: #007BFF; font-weight: bold; }
        .status-inprogress { color: #ffc107; font-weight: bold; }
        .status-completed { color: #28a745; font-weight: bold; }
        .status-cancelled { color: #dc3545; font-weight: bold; }
        .status-unknown { color: #6c757d; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h2>🔬 Manage Operations</h2>

    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success"> Operation saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">Operation deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Operation' : 'Add New Operation'; ?></h3>
        <form method="POST">
            <input type="hidden" name="op_id" value="<?php echo $edit ? $edit['op_id'] : 0; ?>">
            <!-- Patient Name -->
            <div class="form-group">
                <label>Patient Name <span class="req"></span></label>
                <input type="text" name="patient_name" 
                       value="<?php echo $edit ? htmlspecialchars($edit['patient_name']) : ''; ?>" 
                       required autocomplete="off">
                <span class="hint"></span>
            </div>
            <!-- Doctor -->
            <div class="form-group">
                <label>Doctor <span class="req"></span></label>
                <select name="doctor_id" required>
                    <option value=""></option>
                    <?php foreach ($doctors as $d): ?>
                        <option value="<?php echo $d['doctor_id']; ?>" 
                            <?php echo ($edit && $edit['doctor_id'] == $d['doctor_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($d['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($doctors)): ?>
                    <span class="hint" style="color:red;">No doctors.</span>
                <?php endif; ?>
            </div>
            <!-- Operation Date -->
            <div class="form-group">
                <label>Operation Date <span class="req"></span></label>
                <input type="datetime-local" name="operation_date" 
                       value="<?php echo $edit ? date('Y-m-d\TH:i', strtotime($edit['operation_date'])) : ''; ?>" required>
            </div>
            <!-- Operation Type -->
            <div class="form-group">
                <label>Operation Type <span class="req"></span></label>
                <input type="text" name="operation_type" 
                       value="<?php echo $edit ? htmlspecialchars($edit['operation_type']) : ''; ?>" required>
            </div>
            <!-- Room -->
            <div class="form-group">
                <label>Room</label>
                <input type="text" name="room" 
                       value="<?php echo $edit ? htmlspecialchars($edit['room']) : ''; ?>">
            </div>
            <!-- Status -->
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Scheduled" <?php echo ($edit && $edit['status'] == 'Scheduled') ? 'selected' : ''; ?>>Scheduled</option>
                    <option value="In Progress" <?php echo ($edit && $edit['status'] == 'In Progress') ? 'selected' : ''; ?>>In Progress</option>
                    <option value="Completed" <?php echo ($edit && $edit['status'] == 'Completed') ? 'selected' : ''; ?>>Completed</option>
                    <option value="Cancelled" <?php echo ($edit && $edit['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                </select>
            </div>
            <!-- Notes -->
            <div class="form-group">
                <label>Notes</label>
                <textarea name="notes" rows="3" ><?php echo $edit ? htmlspecialchars($edit['notes']) : ''; ?></textarea>
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="operation.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="toolbar">
        <h3>All Operations</h3>
        <a href="operation.php" class="btn btn-primary">➕ Add New</a>
    </div>
    <?php if (count($operations) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Date & Time</th>
                        <th>Type</th>
                        <th>Room</th>
                        <th>Status</th>
                        <th>Notes</th>
                        <th>Created</th>
                        <th style="width:130px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($operations as $op): ?>
                        <tr>
                            <td><?php echo $op['op_id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($op['patient_name'] ?? 'N/A'); ?></strong></td>
                            <td><?php echo htmlspecialchars($op['doctor_name'] ?? 'N/A'); ?></td>
                            <td><?php echo date('d-M-Y h:i A', strtotime($op['operation_date'])); ?></td>
                            <td><?php echo htmlspecialchars($op['operation_type']); ?></td>
                            <td><?php echo htmlspecialchars($op['room']); ?></td>
                            <td>
                                <?php
                                $status_text = $op['status'] ?? 'N/A';
                                $status_class = 'status-unknown';
                                if ($status_text == 'Scheduled') {
                                    $status_class = 'status-scheduled';
                                } elseif ($status_text == 'In Progress') {
                                    $status_class = 'status-inprogress';
                                } elseif ($status_text == 'Completed') {
                                    $status_class = 'status-completed';
                                } elseif ($status_text == 'Cancelled') {
                                    $status_class = 'status-cancelled';
                                }
                                ?>
                                <span class="<?php echo $status_class; ?>">
                                    <?php echo htmlspecialchars($status_text); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($op['notes']); ?></td>
                            <td><?php echo date('d-M-Y', strtotime($op['created_at'])); ?></td>
                            <td>
                                <div class="actions">
                                    <a href="operation.php?edit=<?php echo $op['op_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="operation.php?delete=<?php echo $op['op_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No operations.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>