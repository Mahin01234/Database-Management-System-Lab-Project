<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();  }
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $check = mysqli_query($conn, "SELECT call_id FROM ambulance_call WHERE call_id = $id");
    if (mysqli_num_rows($check) == 0) {
        $msg = "Delete failed: Record with ID $id does not exist.";
    } else {
        $del = mysqli_query($conn, "DELETE FROM ambulance_call WHERE call_id = $id");
        if ($del) {
            header("Location: ambulance_call.php?del=ok");
            exit();
        } else {
            $msg = "Delete failed: " . mysqli_error($conn);        }
    }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['call_id']);
    $patient_name = trim(mysqli_real_escape_string($conn, $_POST['patient_name']));
    $call_date = trim(mysqli_real_escape_string($conn, $_POST['call_date']));
    $call_time = trim(mysqli_real_escape_string($conn, $_POST['call_time']));
    $pickup = trim(mysqli_real_escape_string($conn, $_POST['pickup_location']));
    $dropoff = trim(mysqli_real_escape_string($conn, $_POST['drop_location']));
    $status = trim(mysqli_real_escape_string($conn, $_POST['status']));
    if (empty($patient_name) || empty($call_date) || empty($call_time) || empty($pickup)) {
        $msg = "Please enter patient name, date, time and pickup location.";
    } else {
        $check = mysqli_query($conn, "SELECT patient_id FROM patient WHERE name = '$patient_name'");
        if (mysqli_num_rows($check) > 0) {
            $row = mysqli_fetch_assoc($check);
            $patient_id = $row['patient_id'];
        } else {
            $insert = mysqli_query($conn, "INSERT INTO patient (name, status, registration_date) 
                                           VALUES ('$patient_name', 'Active', NOW())");
            if ($insert) {
                $patient_id = mysqli_insert_id($conn);
            } else {
                $msg = "Failed to create new patient: " . mysqli_error($conn);
                $patient_id = 0;            }
        }
        if ($patient_id > 0) {
            if ($id == 0) {
                $sql = "INSERT INTO ambulance_call (patient_id, call_date, call_time, pickup_location, drop_location, status)
                        VALUES ($patient_id, '$call_date', '$call_time', '$pickup', '$dropoff', '$status')";
            } else {
                $sql = "UPDATE ambulance_call SET
                        patient_id = $patient_id,
                        call_date = '$call_date',
                        call_time = '$call_time',
                        pickup_location = '$pickup',
                        drop_location = '$dropoff',
                        status = '$status'
                        WHERE call_id = $id";            }
            if (mysqli_query($conn, $sql)) {
                header("Location: ambulance_call.php?save=ok");
                exit();
            } else {
                $msg = "Save failed: " . mysqli_error($conn);            }
        }
    }
}
$res = mysqli_query($conn, "SELECT c.call_id, c.patient_id, c.call_date, c.call_time, c.pickup_location, c.drop_location, c.status, p.name AS patient_name 
                            FROM ambulance_call c
                            LEFT JOIN patient p ON c.patient_id = p.patient_id
                            ORDER BY c.call_id ASC");
$calls = [];
if ($res && mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        $calls[] = $row;    }
} else {
    if ($res === false) {
        $msg = "Fetch failed: " . mysqli_error($conn);   }
}
$edit = null;
if (isset($_GET['edit']) && intval($_GET['edit']) > 0) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT c.call_id, c.patient_id, c.call_date, c.call_time, c.pickup_location, c.drop_location, c.status, p.name AS patient_name 
                              FROM ambulance_call c
                              LEFT JOIN patient p ON c.patient_id = p.patient_id
                              WHERE c.call_id = $eid");
    if ($q && mysqli_num_rows($q) > 0) {
        $edit = mysqli_fetch_assoc($q);
    } else {
        $msg = "Edit failed: " . mysqli_error($conn);
        $edit = null;   }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Ambulance Calls</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Ambulance Calls</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">✔ Ambulance call saved successfully!</div>
    <?php endif; ?>

    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">✔ Ambulance call deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error">✖ <?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Ambulance Call' : 'Add New Ambulance Call'; ?></h3>
        <form method="POST">
            <input type="hidden" name="call_id" value="<?php echo $edit ? $edit['call_id'] : 0; ?>">

            <div class="form-group">
                <label>Patient Name <span class="req"></span></label>
                <input type="text" name="patient_name" 
                       value="<?php echo $edit ? htmlspecialchars($edit['patient_name']) : ''; ?>" 
                       required autocomplete="off">
            </div>
            <div class="form-group">
                <label>Date <span class="req"></span></label>
                <input type="date" name="call_date" 
                       value="<?php echo $edit ? $edit['call_date'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Call Time <span class="req"></span></label>
                <input type="time" name="call_time" 
                       value="<?php echo $edit ? $edit['call_time'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Pickup <span class="req"></span></label>
                <input type="text" name="pickup_location" 
                       value="<?php echo $edit ? htmlspecialchars($edit['pickup_location']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Dropoff</label>
                <input type="text" name="drop_location" 
                       value="<?php echo $edit ? htmlspecialchars($edit['drop_location']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Pending" <?php echo ($edit && $edit['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                    <option value="In Progress" <?php echo ($edit && $edit['status'] == 'In Progress') ? 'selected' : ''; ?>>In Progress</option>
                    <option value="Completed" <?php echo ($edit && $edit['status'] == 'Completed') ? 'selected' : ''; ?>>Completed</option>
                    <option value="Cancelled" <?php echo ($edit && $edit['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                </select>
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="ambulance_call.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="toolbar">
        <h3>All Ambulance Calls</h3>
        <a href="ambulance_call.php" class="btn btn-primary">Add New</a>
    </div>
    <?php if (count($calls) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Date</th>
                        <th>Call Time</th>
                        <th>Pickup</th>
                        <th>Dropoff</th>
                        <th>Status</th>
                        <th style="width:130px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($calls as $call): ?>
                        <tr>
                            <td><?php echo $call['call_id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($call['patient_name'] ?? 'N/A'); ?></strong></td>
                            <td><?php echo date('d-M-Y', strtotime($call['call_date'])); ?></td>
                            <td><?php echo date('h:i A', strtotime($call['call_time'])); ?></td>
                            <td><?php echo htmlspecialchars($call['pickup_location']); ?></td>
                            <td><?php echo htmlspecialchars($call['drop_location']); ?></td>
                            <td>
                                <?php
                                $status_class = '';
                                if ($call['status'] == 'Pending') $status_class = 'status-pending';
                                elseif ($call['status'] == 'In Progress') $status_class = 'status-inprogress';
                                elseif ($call['status'] == 'Completed') $status_class = 'status-completed';
                                elseif ($call['status'] == 'Cancelled') $status_class = 'status-cancelled';
                                ?>
                                <span class="<?php echo $status_class; ?>"><?php echo $call['status']; ?></span>
                            </td>
                            <td>
                                <div class="actions">
                                    <a href="ambulance_call.php?edit=<?php echo $call['call_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="ambulance_call.php?delete=<?php echo $call['call_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No ambulance calls found. Add one using the form above.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>