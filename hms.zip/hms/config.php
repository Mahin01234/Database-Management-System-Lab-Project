<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$host = "localhost";
$user = "root";
$password = "";
$database = "hms";     
$port = 4306;         
$conn = mysqli_connect($host, $user, $password, $database, $port);
if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}
mysqli_set_charset($conn, "utf8");
?>