<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (!file_exists("config.php")) {
    die("ERROR: config.php file not found in this directory!");   }
session_start();
include "config.php";
if (!$conn) {
    die("ERROR: Database connection failed. Check config.php");   }
$message = "";
$success = "";
if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $name = trim($_POST['name']);
    $role = "user";
    if (empty($username) || empty($password) || empty($name)) {
        $message = "All fields are required!";
    } else {
        $check_stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
        if (!$check_stmt) {
            die("SQL Prepare Error (Check): " . $conn->error);    }
        $check_stmt->bind_param("s", $username);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        if ($check_result->num_rows > 0) {
            $message = "Username already exists! Choose another.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_stmt = $conn->prepare("INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)");
            if (!$insert_stmt) {
                die("SQL Prepare Error (Insert): " . $conn->error);  }
            $insert_stmt->bind_param("ssss", $username, $hashed_password, $name, $role);
            if ($insert_stmt->execute()) {
                $success = "Registration successful! You can now login.";
                $_POST = [];
            } else {
                $message = "Registration failed: " . $insert_stmt->error;  }
            $insert_stmt->close();  }
        $check_stmt->close();   }    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register - Hospital Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="register-page">
    <div class="register-box">
        <h2>Hospital Management</h2>
        <h3>Create Account</h3>
        <?php if ($message): ?>
            <p class="error"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>
        <?php if ($success): ?>
            <p class="success"><?php echo htmlspecialchars($success); ?></p>
        <?php endif; ?>
        <form method="POST">
            <div class="form-row">
                <label>Full Name</label>
                <input type="text" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required>
            </div>
            <div class="form-row">
                <label>Username</label>
                <input type="text" name="username" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
            </div>
            <div class="form-row">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" name="register">Register</button>
        </form>
        <div class="link">
            Already have an account? <a href="login.php">Login here</a>
        </div>
    </div>
</body>
</html>