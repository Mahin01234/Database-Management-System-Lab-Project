<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (!file_exists("config.php")) {
    die("ERROR: config.php file not found in this directory!");
}
session_start();
include "config.php";
if (!$conn) {
    die("ERROR: Database connection failed. Check config.php");
}
$message = "";
$success = "";
if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $name = trim($_POST['name']);
    $role = "user";
    if (empty($username) || empty($password) || empty($name)) {
        $message = "All fields are required!";
    } else {
        $check_stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
        if (!$check_stmt) {
            die("SQL Prepare Error (Check): " . $conn->error);
        }
        $check_stmt->bind_param("s", $username);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        if ($check_result->num_rows > 0) {
            $message = "Username already exists! Choose another.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_stmt = $conn->prepare("INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)");
            if (!$insert_stmt) {
                die("SQL Prepare Error (Insert): " . $conn->error);
            }
            $insert_stmt->bind_param("ssss", $username, $hashed_password, $name, $role);
            if ($insert_stmt->execute()) {
                $success = "Registration successful! You can now login.";
                $_POST = [];
            } else {
                $message = "Registration failed: " . $insert_stmt->error;
            }
            $insert_stmt->close();
        }
        $check_stmt->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register - Hospital Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>

        .register-page {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, rgba(0, 51, 102, 0.85), rgba(0, 123, 255, 0.75)),
                        url('https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=1600') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .register-page .register-box {
            text-align: center;
            background: rgba(255, 255, 255, 0.95);
            padding: 45px 55px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
            max-width: 500px;
            width: 90%;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: fadeInUp 0.8s ease;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .register-page .register-box h2 {
            font-size: 32px;
            color: #003366;
            border-bottom: none;
            padding-bottom: 0;
            margin-bottom: 5px;
            letter-spacing: 1px;
        }
        .register-page .register-box h2 span { color: #003366; }
        .register-page .register-box h3 {
            font-size: 26px;
            color: #003366;
            margin-top: 0;
            margin-bottom: 25px;
            font-weight: 600;
        }
        .register-page .register-box .logo-icon {
            font-size: 60px;
            display: block;
            margin-bottom: 10px;
        }

        .register-page .register-box label {
            font-size: 18px;
            font-weight: 600;
            color: #003366;
            display: inline-block;
            width: 120px;
            text-align: right;
            margin-right: 12px;
        }


        .register-page .register-box input[type="text"],
        .register-page .register-box input[type="password"] {
            font-size: 20px;
            padding: 10px 14px;
            border: 2px solid #dce1e8;
            border-radius: 10px;
            width: 200px;
            margin-bottom: 18px;
            box-sizing: border-box;
            transition: 0.3s;
            background: #f8faff;
        }

        .register-page .register-box input[type="text"]:focus,
        .register-page .register-box input[type="password"]:focus {
            border-color: #007BFF;
            outline: none;
            box-shadow: 0 0 0 4px rgba(0, 123, 255, 0.15);
            background: #ffffff;
        }

        .register-page .register-box button[type="submit"] {
            font-size: 22px;
            font-weight: 700;
            background: linear-gradient(135deg, #28a745, #1e7e34);
            color: white;
            border: none;
            padding: 12px 50px;
            border-radius: 50px;
            cursor: pointer;
            margin-top: 10px;
            transition: 0.3s;
            letter-spacing: 1px;
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
        }

        .register-page .register-box button[type="submit"]:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(40, 167, 69, 0.5);
            background: linear-gradient(135deg, #1a7a2e, #145a22);
        }

        .register-page .register-box .error {
            font-size: 18px;
            color: #dc3545;
            font-weight: 600;
            margin-top: 15px;
            background: #f8d7da;
            padding: 10px;
            border-radius: 10px;
            border: 1px solid #f5c6cb;
        }

        .register-page .register-box .success {
            font-size: 18px;
            color: #28a745;
            font-weight: 600;
            margin-top: 15px;
            background: #d4edda;
            padding: 10px;
            border-radius: 10px;
            border: 1px solid #c3e6cb;
        }

        .register-page .register-box .form-row {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 8px;
            flex-wrap: wrap;
        }

        .register-page .register-box .link {
            margin-top: 22px;
            font-size: 17px;
            color: #495057;
        }

        .register-page .register-box .link a {
            color: #007BFF;
            text-decoration: none;
            font-weight: 600;
            transition: 0.3s;
        }

        .register-page .register-box .link a:hover {
            color: #003366;
            text-decoration: underline;
        }

        .register-page .register-box .credit {
            margin-top: 18px;
            font-size: 13px;
            color: #aab4d6;
        }


        @media (max-width: 640px) {
            .register-page .register-box {
                padding: 30px 25px;
            }
            .register-page .register-box h2 { font-size: 24px; }
            .register-page .register-box h3 { font-size: 22px; }
            .register-page .register-box label {
                display: block;
                text-align: center;
                width: auto;
                margin-right: 0;
                margin-bottom: 3px;
            }
            .register-page .register-box input[type="text"],
            .register-page .register-box input[type="password"] {
                width: 100%;
                font-size: 18px;
            }
            .register-page .register-box .form-row {
                flex-direction: column;
                align-items: stretch;
            }
            .register-page .register-box button[type="submit"] {
                width: 100%;
                font-size: 20px;
                padding: 12px;
            }
        }
    </style>
</head>
<body class="register-page">
    <div class="register-box">
        <span class="logo-icon"></span>
        <h2>Hospital <span>Management</span></h2>
        <h3>Create Account</h3>
        
        <?php if ($message): ?>
            <p class="error"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>
        <?php if ($success): ?>
            <p class="success"><?php echo htmlspecialchars($success); ?></p>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-row">
                <label>Full Name</label>
                <input type="text" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required>
            </div>
            <div class="form-row">
                <label>Username</label>
                <input type="text" name="username" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
            </div>
            <div class="form-row">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter your password" required>
            </div>
            <button type="submit" name="register">Register</button>
        </form>
        
        <div class="link">
            Already have an account? <a href="login.php">Login here</a>
        </div>
      
    </div>
</body>
</html>