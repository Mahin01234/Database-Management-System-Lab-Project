<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";

$filter_from = $_GET['from'] ?? date('Y-m-d', strtotime('-30 days'));
$filter_to = $_GET['to'] ?? date('Y-m-d');
$filter_dept = intval($_GET['dept'] ?? 0);
$filter_doctor = intval($_GET['doctor'] ?? 0);
$filter_appt_status = $_GET['appt_status'] ?? '';
$filter_lab_status = $_GET['lab_status'] ?? '';
$filter_ward = intval($_GET['ward'] ?? 0);
$filter_blood = $_GET['blood'] ?? '';
$filter_search = trim($_GET['search'] ?? '');


function buildWhere($conditions) {
    $parts = array_filter($conditions, function($v) { return !empty($v); });
    return empty($parts) ? '' : 'WHERE ' . implode(' AND ', $parts);
}


$conds = [];
if ($filter_from && $filter_to) {
    $conds[] = "DATE(registration_date) BETWEEN '$filter_from' AND '$filter_to'";
}
if (!empty($filter_search)) {
    $search = mysqli_real_escape_string($GLOBALS['conn'], $filter_search);
    $conds[] = "(name LIKE '%$search%' OR patient_id = '$search')";
}
if (!empty($filter_blood)) {
    $blood = mysqli_real_escape_string($GLOBALS['conn'], $filter_blood);
    $conds[] = "blood_group = '$blood'";
}
$patient_where = buildWhere($conds);


$total_patients = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM patient $patient_where"))['total'];


$doc_where = '';
if ($filter_dept > 0) $doc_where = "WHERE dept_id = $filter_dept";
$total_doctors = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM doctor $doc_where"))['total'];


$nurse_where = "WHERE role = 'Nurse'";
if ($filter_dept > 0) $nurse_where .= " AND dept_id = $filter_dept";
$total_nurses = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM staff $nurse_where"))['total'];


$bill_conds = [];
if ($filter_from && $filter_to) $bill_conds[] = "DATE(bill_date) BETWEEN '$filter_from' AND '$filter_to'";
if ($filter_doctor > 0) {

    $bill_conds[] = "b.patient_id IN (SELECT patient_id FROM appointment WHERE doctor_id = $filter_doctor)";
}
$bill_where = buildWhere($bill_conds);
$total_revenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(b.total_amount) AS total FROM billing b $bill_where"))['total'] ?? 0;


$lab_conds = [];
if ($filter_lab_status) $lab_conds[] = "status = '" . mysqli_real_escape_string($conn, $filter_lab_status) . "'";
if ($filter_doctor > 0) $lab_conds[] = "doctor_id = $filter_doctor";
if ($filter_from && $filter_to) $lab_conds[] = "DATE(test_date) BETWEEN '$filter_from' AND '$filter_to'";
$lab_where = buildWhere($lab_conds);
$pending_labtests = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM labtest $lab_where"))['total'] ?? 0;


$today_appointments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM appointment WHERE DATE(appointment_date) = CURDATE()"))['total'];

$bed_where = '';
if ($filter_ward > 0) $bed_where = "WHERE ward_id = $filter_ward";
$total_beds = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(capacity) AS total FROM ward $bed_where"))['total'] ?? 0;
$occupied_beds = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(current_occupancy) AS total FROM ward $bed_where"))['total'] ?? 0;
$bed_occupancy_percent = ($total_beds > 0) ? round(($occupied_beds / $total_beds) * 100, 1) : 0;


$today_revenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) AS total FROM billing WHERE DATE(bill_date) = CURDATE()"))['total'] ?? 0;


$daily_patients = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $search_sql = !empty($filter_search) ? "AND name LIKE '%" . mysqli_real_escape_string($conn, $filter_search) . "%'" : "";
    $blood_sql = !empty($filter_blood) ? "AND blood_group = '" . mysqli_real_escape_string($conn, $filter_blood) . "'" : "";
    $count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM patient WHERE DATE(registration_date) = '$date' $search_sql $blood_sql"))['total'];
    $daily_patients[] = ['date' => date('d M', strtotime($date)), 'count' => $count];
}


$monthly_revenue = [];
$rev_sql = "SELECT DATE_FORMAT(bill_date, '%b %Y') AS month, SUM(total_amount) AS total 
            FROM billing 
            WHERE bill_date >= CURDATE() - INTERVAL 12 MONTH";
if ($filter_from && $filter_to) $rev_sql .= " AND DATE(bill_date) BETWEEN '$filter_from' AND '$filter_to'";
$rev_sql .= " GROUP BY YEAR(bill_date), MONTH(bill_date) ORDER BY bill_date ASC";
$rev_res = mysqli_query($conn, $rev_sql);
while ($row = mysqli_fetch_assoc($rev_res)) { $monthly_revenue[] = $row; }


$appt_conds = [];
if ($filter_appt_status) $appt_conds[] = "status = '" . mysqli_real_escape_string($conn, $filter_appt_status) . "'";
if ($filter_doctor > 0) $appt_conds[] = "doctor_id = $filter_doctor";
if ($filter_dept > 0) $appt_conds[] = "doctor_id IN (SELECT doctor_id FROM doctor WHERE dept_id = $filter_dept)";
if ($filter_from && $filter_to) $appt_conds[] = "DATE(appointment_date) BETWEEN '$filter_from' AND '$filter_to'";
$appt_where = buildWhere($appt_conds);
$appt_status = [];
$ast_res = mysqli_query($conn, "SELECT status, COUNT(*) AS count FROM appointment $appt_where GROUP BY status");
while ($row = mysqli_fetch_assoc($ast_res)) { $appt_status[] = $row; }


$lab_status = [];
$lst_res = mysqli_query($conn, "SELECT status, COUNT(*) AS count FROM labtest $lab_where GROUP BY status");
while ($row = mysqli_fetch_assoc($lst_res)) { $lab_status[] = $row; }


$dept_where = ($filter_dept > 0) ? "WHERE d.dept_id = $filter_dept" : "";
$dept_doctors = [];
$dd_res = mysqli_query($conn, "
    SELECT d.name AS dept_name, COUNT(doc.doctor_id) AS total 
    FROM department d 
    LEFT JOIN doctor doc ON d.dept_id = doc.dept_id 
    $dept_where
    GROUP BY d.dept_id 
    ORDER BY total DESC
");
while ($row = mysqli_fetch_assoc($dd_res)) { $dept_doctors[] = $row; }


$gender_data = [];
$gd_res = mysqli_query($conn, "SELECT gender, COUNT(*) AS count FROM patient $patient_where GROUP BY gender");
while ($row = mysqli_fetch_assoc($gd_res)) { $gender_data[] = $row; }


$recent_activities = [];
$activity_res = mysqli_query($conn, "
    (SELECT 'appointment' AS type, appointment_id AS id, CONCAT('New appointment for ', p.name) AS description, appointment_date AS created_at 
     FROM appointment a JOIN patient p ON a.patient_id = p.patient_id 
     WHERE 1=1 " . ($filter_doctor > 0 ? "AND a.doctor_id = $filter_doctor" : "") . " 
     ORDER BY appointment_date DESC LIMIT 5)
    UNION ALL
    (SELECT 'billing' AS type, bill_id AS id, CONCAT('Bill #', bill_id, ' for ', p.name) AS description, bill_date AS created_at 
     FROM billing b JOIN patient p ON b.patient_id = p.patient_id 
     WHERE 1=1 " . ($filter_from && $filter_to ? "AND DATE(bill_date) BETWEEN '$filter_from' AND '$filter_to'" : "") . " 
     ORDER BY bill_date DESC LIMIT 5)
    UNION ALL
    (SELECT 'patient' AS type, patient_id AS id, CONCAT('New patient: ', name) AS description, registration_date AS created_at 
     FROM patient 
     $patient_where
     ORDER BY registration_date DESC LIMIT 5)
    ORDER BY created_at DESC LIMIT 15
");
while ($row = mysqli_fetch_assoc($activity_res)) { $recent_activities[] = $row; }


$depts = [];
$d_res = mysqli_query($conn, "SELECT dept_id, name FROM department ORDER BY name");
while ($d = mysqli_fetch_assoc($d_res)) $depts[] = $d;

$doctors = [];
$doc_res = mysqli_query($conn, "SELECT doctor_id, name FROM doctor ORDER BY name");
while ($d = mysqli_fetch_assoc($doc_res)) $doctors[] = $d;

$wards = [];
$w_res = mysqli_query($conn, "SELECT ward_id, ward_number FROM ward ORDER BY ward_number");
while ($w = mysqli_fetch_assoc($w_res)) $wards[] = $w;

$blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
$appt_statuses = ['Scheduled', 'Completed', 'Cancelled', 'No-Show'];
$lab_statuses = ['Pending', 'Completed', 'In Progress', 'Cancelled'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced Analytics Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
   
        .filter-bar {
            background: #f1f8ff;
            padding: 18px 20px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 12px 18px;
            border: 1px solid #dbeafe;
        }
        .filter-bar .filter-group {
            display: flex;
            flex-direction: column;
            gap: 3px;
        }
        .filter-bar .filter-group label {
            font-size: 12px;
            font-weight: 700;
            color: #003366;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .filter-bar .filter-group input,
        .filter-bar .filter-group select {
            padding: 6px 12px;
            border: 1px solid #ced4da;
            border-radius: 6px;
            font-size: 14px;
            min-width: 140px;
            background: #fff;
        }
        .filter-bar .filter-group input:focus,
        .filter-bar .filter-group select:focus {
            border-color: #007BFF;
            outline: none;
            box-shadow: 0 0 0 3px rgba(0,123,255,0.15);
        }
        .filter-bar .btn-group {
            display: flex;
            gap: 8px;
            align-items: flex-end;
            padding-bottom: 2px;
        }
        .filter-bar .btn {
            padding: 6px 20px;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-filter { background: #007BFF; color: white; }
        .btn-filter:hover { background: #0056b3; }
        .btn-reset { background: #6c757d; color: white; }
        .btn-reset:hover { background: #5a6268; }

      
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        .kpi-card {
            background: #f8f9fc;
            border-radius: 12px;
            padding: 15px 10px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            border-left: 5px solid #007BFF;
        }
        .kpi-card .number { font-size: 26px; font-weight: 700; color: #003366; }
        .kpi-card .label { font-size: 13px; color: #6c757d; margin-top: 3px; }
        .kpi-card .sub { font-size: 12px; color: #28a745; }

        .chart-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        .chart-box {
            background: #ffffff;
            border-radius: 12px;
            padding: 15px;
            border: 1px solid #e9ecef;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        }
        .chart-box h4 { margin: 0 0 10px 0; color: #003366; font-size: 15px; text-align: center; }
        .chart-box.wide { grid-column: span 2; }
        .chart-box.full { grid-column: span 3; }

        .activity-table {
            width: 100%; border-collapse: collapse; font-size: 13px;
        }
        .activity-table th { background: #007BFF; color: white; padding: 6px 10px; text-align: left; }
        .activity-table td { padding: 6px 10px; border-bottom: 1px solid #dee2e6; }
        .activity-table tr:hover { background: #f1f8ff; }
        .badge-type {
            display: inline-block; padding: 2px 10px; border-radius: 50px;
            font-size: 11px; font-weight: bold;
        }
        .badge-appointment { background: #ffc107; color: #212529; }
        .badge-billing { background: #28a745; color: white; }
        .badge-patient { background: #17a2b8; color: white; }

        @media (max-width: 992px) { .chart-grid { grid-template-columns: 1fr 1fr; } .chart-box.wide { grid-column: span 2; } .chart-box.full { grid-column: span 2; } }
        @media (max-width: 600px) { .chart-grid { grid-template-columns: 1fr; } .chart-box.wide { grid-column: span 1; } .chart-box.full { grid-column: span 1; } }
        @media (max-width: 500px) { .filter-bar .filter-group { width: 100%; } .filter-bar .filter-group input, .filter-bar .filter-group select { width: 100%; min-width: auto; } }
    </style>
</head>
<body>
<div class="container" style="max-width: 1500px;">
    <h2> Advanced Analytics Dashboard</h2>


    <form method="GET" class="filter-bar" id="filterForm">
        <div class="filter-group">
            <label>From</label>
            <input type="date" name="from" value="<?= $filter_from ?>">
        </div>
        <div class="filter-group">
            <label>To</label>
            <input type="date" name="to" value="<?= $filter_to ?>">
        </div>
        <div class="filter-group">
            <label>Department</label>
            <select name="dept">
                <option value="0">All</option>
                <?php foreach ($depts as $d): ?>
                <option value="<?= $d['dept_id'] ?>" <?= ($filter_dept == $d['dept_id']) ? 'selected' : '' ?>><?= htmlspecialchars($d['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-group">
            <label>Doctor</label>
            <select name="doctor">
                <option value="0">All</option>
                <?php foreach ($doctors as $d): ?>
                <option value="<?= $d['doctor_id'] ?>" <?= ($filter_doctor == $d['doctor_id']) ? 'selected' : '' ?>><?= htmlspecialchars($d['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-group">
            <label>Appt Status</label>
            <select name="appt_status">
                <option value="">All</option>
                <?php foreach ($appt_statuses as $s): ?>
                <option value="<?= $s ?>" <?= ($filter_appt_status == $s) ? 'selected' : '' ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-group">
            <label>Lab Status</label>
            <select name="lab_status">
                <option value="">All</option>
                <?php foreach ($lab_statuses as $s): ?>
                <option value="<?= $s ?>" <?= ($filter_lab_status == $s) ? 'selected' : '' ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-group">
            <label>Ward</label>
            <select name="ward">
                <option value="0">All</option>
                <?php foreach ($wards as $w): ?>
                <option value="<?= $w['ward_id'] ?>" <?= ($filter_ward == $w['ward_id']) ? 'selected' : '' ?>>Ward <?= htmlspecialchars($w['ward_number']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-group">
            <label>Blood Group</label>
            <select name="blood">
                <option value="">All</option>
                <?php foreach ($blood_groups as $bg): ?>
                <option value="<?= $bg ?>" <?= ($filter_blood == $bg) ? 'selected' : '' ?>><?= $bg ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-group" style="flex:2;">
            <label>Search (Patient)</label>
            <input type="text" name="search" placeholder="Name or ID..." value="<?= htmlspecialchars($filter_search) ?>">
        </div>
        <div class="btn-group">
            <button type="submit" class="btn btn-filter">Apply Filters</button>
            <a href="analytics_dashboard.php" class="btn btn-reset">Reset</a>
        </div>
    </form>


    <div class="kpi-grid">
        <div class="kpi-card" style="border-left-color:#003366;">
            <div class="number"><?= number_format($total_patients) ?></div>
            <div class="label">Total Patients</div>
        </div>
        <div class="kpi-card" style="border-left-color:#28a745;">
            <div class="number"><?= $total_doctors ?></div>
            <div class="label">Total Doctors</div>
        </div>
        <div class="kpi-card" style="border-left-color:#17a2b8;">
            <div class="number"><?= $total_nurses ?></div>
            <div class="label">Total Nurses</div>
        </div>
        <div class="kpi-card" style="border-left-color:#ffc107;">
            <div class="number"><?= number_format($total_revenue, 2) ?></div>
            <div class="label">Total Revenue (BDT)</div>
        </div>
        <div class="kpi-card" style="border-left-color:#dc3545;">
            <div class="number"><?= $pending_labtests ?></div>
            <div class="label">Filtered Lab Tests</div>
        </div>
    </div>
    <div class="kpi-grid" style="margin-bottom:30px;">
        <div class="kpi-card" style="border-left-color:#007BFF;">
            <div class="number"><?= $today_appointments ?></div>
            <div class="label">Today's Appointments</div>
        </div>
        <div class="kpi-card" style="border-left-color:#28a745;">
            <div class="number"><?= $bed_occupancy_percent ?>%</div>
            <div class="label">Bed Occupancy</div>
            <div class="sub"><?= $occupied_beds ?> / <?= $total_beds ?></div>
        </div>
        <div class="kpi-card" style="border-left-color:#dc3545;">
            <div class="number"><?= number_format($today_revenue, 2) ?></div>
            <div class="label">Today's Revenue</div>
        </div>
    </div>


    <div class="chart-grid">
        <div class="chart-box wide">
            <h4>📈 Daily Patient Registration (Last 7 Days)</h4>
            <canvas id="lineChart" height="120"></canvas>
        </div>
        <div class="chart-box">
            <h4>💰 Monthly Revenue (12 Months)</h4>
            <canvas id="revenueChart" height="120"></canvas>
        </div>
        <div class="chart-box">
            <h4>📅 Appointment Status</h4>
            <canvas id="apptStatusChart" height="120"></canvas>
        </div>
        <div class="chart-box">
            <h4>🧪 Lab Test Status</h4>
            <canvas id="labStatusChart" height="120"></canvas>
        </div>
        <div class="chart-box">
            <h4>👨‍⚕️ Doctors by Department</h4>
            <canvas id="deptDoctorChart" height="120"></canvas>
        </div>
        <div class="chart-box">
            <h4>👤 Patient Gender Ratio</h4>
            <canvas id="genderChart" height="120"></canvas>
        </div>
        <div class="chart-box full">
            <h4>📋 Recent Activities (Filtered)</h4>
            <table class="activity-table">
                <thead><tr><th>Type</th><th>Description</th><th>Time</th></tr></thead>
                <tbody>
                    <?php foreach ($recent_activities as $act): ?>
                    <tr><td><span class="badge-type badge-<?= $act['type'] ?>"><?= ucfirst($act['type']) ?></span></td><td><?= htmlspecialchars($act['description']) ?></td><td><?= date('d-M H:i', strtotime($act['created_at'])) ?></td></tr>
                    <?php endforeach; ?>
                    <?php if (empty($recent_activities)): ?>
                    <tr><td colspan="3" style="text-align:center; color:#6c757d;">No recent activities found with current filters.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>

<script>
const dailyData = <?= json_encode($daily_patients) ?>;
new Chart(document.getElementById('lineChart'), {
    type: 'line',
    data: {
        labels: dailyData.map(d => d.date),
        datasets: [{ label: 'Patients', data: dailyData.map(d => d.count), borderColor: '#007BFF', backgroundColor: 'rgba(0,123,255,0.1)', tension: 0.3, fill: true, pointBackgroundColor: '#003366' }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
});

const revData = <?= json_encode($monthly_revenue) ?>;
new Chart(document.getElementById('revenueChart'), {
    type: 'line',
    data: {
        labels: revData.map(d => d.month),
        datasets: [{ label: 'Revenue (BDT)', data: revData.map(d => d.total), borderColor: '#28a745', backgroundColor: 'rgba(40,167,69,0.1)', tension: 0.3, fill: true, pointBackgroundColor: '#1e7e34' }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
});


const apptStatus = <?= json_encode($appt_status) ?>;
const colors1 = ['#007BFF', '#28a745', '#dc3545', '#ffc107', '#6c757d'];
new Chart(document.getElementById('apptStatusChart'), {
    type: 'pie',
    data: {
        labels: apptStatus.map(d => d.status || 'Unknown'),
        datasets: [{ data: apptStatus.map(d => d.count), backgroundColor: colors1.slice(0, apptStatus.length), borderColor: '#fff', borderWidth: 2 }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { boxWidth: 12 } } } }
});


const labStatus = <?= json_encode($lab_status) ?>;
const colors2 = ['#ffc107', '#28a745', '#dc3545', '#17a2b8'];
new Chart(document.getElementById('labStatusChart'), {
    type: 'pie',
    data: {
        labels: labStatus.map(d => d.status || 'Unknown'),
        datasets: [{ data: labStatus.map(d => d.count), backgroundColor: colors2.slice(0, labStatus.length), borderColor: '#fff', borderWidth: 2 }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { boxWidth: 12 } } } }
});

const deptData = <?= json_encode($dept_doctors) ?>;
new Chart(document.getElementById('deptDoctorChart'), {
    type: 'bar',
    data: {
        labels: deptData.map(d => d.dept_name),
        datasets: [{ label: 'Doctors', data: deptData.map(d => d.total), backgroundColor: 'rgba(23,162,184,0.7)', borderColor: '#17a2b8', borderWidth: 1 }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
});


const genderData = <?= json_encode($gender_data) ?>;
const colors3 = ['#007BFF', '#dc3545', '#6c757d'];
new Chart(document.getElementById('genderChart'), {
    type: 'pie',
    data: {
        labels: genderData.map(d => d.gender || 'Unknown'),
        datasets: [{ data: genderData.map(d => d.count), backgroundColor: colors3.slice(0, genderData.length), borderColor: '#fff', borderWidth: 2 }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { boxWidth: 12 } } } }
});
</script>

</body>
</html>

