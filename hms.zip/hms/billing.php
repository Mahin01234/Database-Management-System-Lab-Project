<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM billing WHERE bill_id = $id");
    if ($del) {
        header("Location: billing.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);  }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['bill_id']);
    $patient_name = trim(mysqli_real_escape_string($conn, $_POST['patient_name']));
    $bill_date = trim(mysqli_real_escape_string($conn, $_POST['bill_date']));
    $total = floatval($_POST['total_amount']);
    $paid = floatval($_POST['paid_amount']);
    $method = trim(mysqli_real_escape_string($conn, $_POST['payment_method']));
    $status = trim(mysqli_real_escape_string($conn, $_POST['payment_status']));
    if (empty($patient_name) || empty($bill_date) || $total <= 0 || $paid < 0) {
        $msg = "Please fill all required fields correctly.";
    } else {
        $check = mysqli_query($conn, "SELECT patient_id FROM patient WHERE name = '$patient_name'");
        if (mysqli_num_rows($check) > 0) {
            $row = mysqli_fetch_assoc($check);
            $patient_id = $row['patient_id'];
        } else {
            $insert = mysqli_query($conn, "INSERT INTO patient (name, status, registration_date) VALUES ('$patient_name', 'Active', NOW())");
            if ($insert) {
                $patient_id = mysqli_insert_id($conn);
            } else {
                $msg = "Failed to create patient: " . mysqli_error($conn);
                $patient_id = 0;            }   }
        if ($patient_id > 0) {
            if ($id == 0) {
                $sql = "INSERT INTO billing (patient_id, bill_date, total_amount, paid_amount, payment_method, payment_status)
                        VALUES ($patient_id, '$bill_date', $total, $paid, '$method', '$status')";
            } else {
                $sql = "UPDATE billing SET
                        patient_id = $patient_id,
                        bill_date = '$bill_date',
                        total_amount = $total,
                        paid_amount = $paid,
                        payment_method = '$method',
                        payment_status = '$status'
                        WHERE bill_id = $id";            }
            if (mysqli_query($conn, $sql)) {
                header("Location: billing.php?save=ok");
                exit();
            } else {
                $msg = "Save failed: " . mysqli_error($conn);         }
        }    }
}
$res = mysqli_query($conn, "SELECT b.*, p.name AS patient_name FROM billing b LEFT JOIN patient p ON b.patient_id = p.patient_id ORDER BY b.bill_id ASC");
$bills = [];
while ($row = mysqli_fetch_assoc($res)) {
    $bills[] = $row;
}
$edit = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT b.*, p.name AS patient_name FROM billing b LEFT JOIN patient p ON b.patient_id = p.patient_id WHERE b.bill_id = $eid");
    if ($q) {
        $edit = mysqli_fetch_assoc($q);    }   
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Billing</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Hospital Billing</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">Bill saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">Bill deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Bill' : 'Add New Bill'; ?></h3>
        <form method="POST">
            <input type="hidden" name="bill_id" value="<?php echo $edit ? $edit['bill_id'] : 0; ?>">
            <div class="form-group">
                <label>Patient Name <span class="req"></span></label>
                <input type="text" name="patient_name" value="<?php echo $edit ? htmlspecialchars($edit['patient_name']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Bill Date <span class="req"></span></label>
                <input type="date" name="bill_date" value="<?php echo $edit ? $edit['bill_date'] : date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label>Total Amount <span class="req"></span></label>
                <input type="number" step="100" name="total_amount" value="<?php echo $edit ? $edit['total_amount'] : ''; ?>" required min="0">
            </div>
            <div class="form-group">
                <label>Paid Amount <span class="req"></span></label>
                <input type="number" step="100" name="paid_amount" value="<?php echo $edit ? $edit['paid_amount'] : ''; ?>" required min="0">
            </div>
            <div class="form-group">
                <label>Payment Method</label>
                <select name="payment_method">
                    <option value="Cash" <?php echo ($edit && $edit['payment_method'] == 'Cash') ? 'selected' : ''; ?>>Cash</option>
                    <option value="Card" <?php echo ($edit && $edit['payment_method'] == 'Card') ? 'selected' : ''; ?>>Card</option>
                    <option value="bKash" <?php echo ($edit && $edit['payment_method'] == 'bKash') ? 'selected' : ''; ?>>bKash</option>
                </select>
            </div>
            <div class="form-group">
                <label>Payment Status</label>
                <select name="payment_status">
                    <option value="Paid" <?php echo ($edit && $edit['payment_status'] == 'Paid') ? 'selected' : ''; ?>>Paid</option>
                    <option value="Unpaid" <?php echo ($edit && $edit['payment_status'] == 'Unpaid') ? 'selected' : ''; ?>>Unpaid</option>
                
                </select>
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="billing.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="toolbar">
        <h3>All Bills</h3>
        <a href="billing.php" class="btn btn-primary">Add New</a>
    </div>
    <?php if (count($bills) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Bill Date</th>
                        <th>Total</th>
                        <th>Paid</th>
                        <th>Method</th>
                        <th>Status</th>
                        <th style="width:130px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bills as $b): ?>
                        <tr>
                            <td><?php echo $b['bill_id']; ?></td>
                            <td><?php echo htmlspecialchars($b['patient_name'] ?? 'N/A'); ?></td>
                            <td><?php echo date('d-M-Y', strtotime($b['bill_date'])); ?></td>
                            <td><?php echo number_format($b['total_amount'], 2); ?></td>
                            <td><?php echo number_format($b['paid_amount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($b['payment_method']); ?></td>
                            <td>
                                <?php
                                $status_value = trim($b['payment_status'] ?? '');
                                if (empty($status_value)) $status_value = 'Unpaid';
                                $class = '';
                                if (strcasecmp($status_value, 'Paid') == 0) $class = 'status-paid';
                                elseif (strcasecmp($status_value, 'Unpaid') == 0) $class = 'status-unpaid';
                                elseif (strcasecmp($status_value, 'Partial') == 0) $class = 'status-partial';
                                ?>
                                <span class="<?php echo $class; ?>"><?php echo htmlspecialchars($status_value); ?></span>
                            </td>
                            <td>
                                <div class="actions">
                                    <a href="billing.php?edit=<?php echo $b['bill_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="billing.php?delete=<?php echo $b['bill_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No bills found.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>