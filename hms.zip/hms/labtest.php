<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM labtest WHERE test_id = $id");
    if ($del) {
        header("Location: labtest.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);
    }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['test_id']);
    $patient_name = trim(mysqli_real_escape_string($conn, $_POST['patient_name']));
    $doctor = intval($_POST['doctor_id']);
    $type = trim(mysqli_real_escape_string($conn, $_POST['test_type']));
    $date = trim(mysqli_real_escape_string($conn, $_POST['test_date']));
    $results = trim(mysqli_real_escape_string($conn, $_POST['results']));
    $status = trim(mysqli_real_escape_string($conn, $_POST['status']));
    $cost = floatval($_POST['cost']);
    if (empty($patient_name) || $doctor == 0 || empty($type) || empty($date)) {
        $msg = "Please enter patient name, select doctor, test type and date.";
    } else {
        $check = mysqli_query($conn, "SELECT patient_id FROM patient WHERE name = '$patient_name'");
        if (mysqli_num_rows($check) > 0) {
            $row = mysqli_fetch_assoc($check);
            $patient_id = $row['patient_id'];
        } else {
            $insert = mysqli_query($conn, "INSERT INTO patient (name, status, registration_date) 
                                           VALUES ('$patient_name', 'Active', NOW())");
            if ($insert) {
                $patient_id = mysqli_insert_id($conn);
            } else {
                $msg = "Failed to create new patient: " . mysqli_error($conn);
                $patient_id = 0;
            }
        }
        if ($patient_id > 0) {
            if ($id == 0) {
                $sql = "INSERT INTO labtest (patient_id, doctor_id, test_type, test_date, results, status, cost)
                        VALUES ($patient_id, $doctor, '$type', '$date', '$results', '$status', $cost)";
            } else {
                $sql = "UPDATE labtest SET
                        patient_id=$patient_id,
                        doctor_id=$doctor,
                        test_type='$type',
                        test_date='$date',
                        results='$results',
                        status='$status',
                        cost=$cost
                        WHERE test_id=$id";
            }
            if (mysqli_query($conn, $sql)) {
                header("Location: labtest.php?save=ok");
                exit();
            } else {
                $msg = "Save failed: " . mysqli_error($conn);
            }
        }
    }
}
$res = mysqli_query($conn, "SELECT l.*, p.name as patient_name, d.name as doctor_name 
                            FROM labtest l
                            LEFT JOIN patient p ON l.patient_id = p.patient_id
                            LEFT JOIN doctor d ON l.doctor_id = d.doctor_id
                            ORDER BY l.test_id ASC");
$tests = [];
while ($row = mysqli_fetch_assoc($res)) {
    $tests[] = $row;
}
$edit = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT l.*, p.name as patient_name 
                              FROM labtest l
                              LEFT JOIN patient p ON l.patient_id = p.patient_id
                              WHERE l.test_id = $eid");
    $edit = mysqli_fetch_assoc($q);
}
$doc_res = mysqli_query($conn, "SELECT doctor_id, name FROM doctor ORDER BY name");
$doctors = [];
while ($d = mysqli_fetch_assoc($doc_res)) {
    $doctors[] = $d;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Lab Tests</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Lab Tests</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">Lab test saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">Lab test deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"><?php echo $msg; ?></div>
    <?php endif; ?>
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Lab Test' : 'Add New Lab Test'; ?></h3>
        <form method="POST">
            <input type="hidden" name="test_id" value="<?php echo $edit ? $edit['test_id'] : 0; ?>">

            <!-- Patient Name: user input (text) -->
            <div class="form-group">
                <label>Patient Name <span class="req"></span></label>
                <input type="text" name="patient_name" 
                       value="<?php echo $edit ? htmlspecialchars($edit['patient_name']) : ''; ?>" 
                       required autocomplete="off">      
            </div>
            <div class="form-group">
                <label>Doctor <span class="req"></span></label>
                <select name="doctor_id" required>
                    <option value=""></option>
                    <?php foreach ($doctors as $d): ?>
                        <option value="<?php echo $d['doctor_id']; ?>" <?php echo ($edit && $edit['doctor_id'] == $d['doctor_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($d['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($doctors)): ?>
                    <span class="hint" style="color:red;">⚠️ No doctors found. Please add doctors first.</span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>Test Type <span class="req"></span></label>
                <input type="text" name="test_type" value="<?php echo $edit ? htmlspecialchars($edit['test_type']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Test Date <span class="req"></span></label>
                <input type="date" name="test_date" value="<?php echo $edit ? $edit['test_date'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Results</label>
                <textarea name="results" rows="3" ><?php echo $edit ? htmlspecialchars($edit['results']) : ''; ?></textarea>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Pending" <?php echo ($edit && $edit['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                    <option value="Completed" <?php echo ($edit && $edit['status'] == 'Completed') ? 'selected' : ''; ?>>Completed</option>
                    <option value="Cancelled" <?php echo ($edit && $edit['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                    <option value="In Progress" <?php echo ($edit && $edit['status'] == 'In Progress') ? 'selected' : ''; ?>>In Progress</option>
                </select>
            </div>
            <div class="form-group">
            <label>Cost (BDT)</label>
            <input type="number"
           name="cost"
           value="<?php echo $edit ? $edit['cost'] : ''; ?>"
           min="100"
           step="100">
           </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="labtest.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="toolbar">
        <h3>All Lab Tests</h3>
        <a href="labtest.php" class="btn btn-primary">Add New</a>
    </div>
    <?php if (count($tests) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Test Type</th>
                        <th>Test Date</th>
                        <th>Results</th>
                        <th>Status</th>
                        <th>Cost</th>
                        <!-- <th>Created</th> -->
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tests as $t): ?>
                        <tr>
                            <td><?php echo $t['test_id']; ?></td>
                            <td><?php echo htmlspecialchars($t['patient_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($t['doctor_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($t['test_type']); ?></td>
                            <td><?php echo date('d-M-Y', strtotime($t['test_date'])); ?></td>
                            <td><?php echo htmlspecialchars($t['results']); ?></td>
                            <td>
                                <?php
                                $color = ($t['status'] == 'Completed') ? 'green' : (($t['status'] == 'Pending') ? 'orange' : (($t['status'] == 'Cancelled') ? 'red' : 'blue'));
                                ?>
                                <span style="color: <?php echo $color; ?>; font-weight:bold;">
                                    <?php echo $t['status']; ?>
                                </span>
                            </td>
                            <td><?php echo number_format($t['cost'], 2); ?></td>
                            <td>
                                <div class="actions" style="display: flex; flex-direction: column; gap: 4px; align-items: center;">
                                    <a href="labtest.php?edit=<?php echo $t['test_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="labtest.php?delete=<?php echo $t['test_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No lab tests found. Add one using the form above.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>