<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";

$msg = "";

// ---------- DELETE ----------
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    // নিজের অ্যাকাউন্ট ডিলিট করতে দেবেন না
    if ($id == $_SESSION['user_id']) {
        $msg = "You cannot delete your own account!";
    } else {
        $del = mysqli_query($conn, "DELETE FROM USERS WHERE user_id = $id");
        if ($del) {
            header("Location: user.php?del=ok");
            exit();
        } else {
            $msg = "Delete failed: " . mysqli_error($conn);
        }
    }
}

// ---------- UPDATE (রোল পরিবর্তন) ----------
if (isset($_POST['update_role'])) {
    $id = intval($_POST['user_id']);
    $role = trim(mysqli_real_escape_string($conn, $_POST['role']));
    
    if ($id == $_SESSION['user_id']) {
        $msg = "You cannot change your own role!";
    } else {
        $sql = "UPDATE USERS SET role = '$role' WHERE user_id = $id";
        if (mysqli_query($conn, $sql)) {
            header("Location: user.php?role=ok");
            exit();
        } else {
            $msg = "Update failed: " . mysqli_error($conn);
        }
    }
}

// ---------- FETCH ALL USERS ----------
$res = mysqli_query($conn, "SELECT user_id, username, name, role, created_at FROM USERS ORDER BY user_id ASC");
$users = [];
while ($row = mysqli_fetch_assoc($res)) {
    $users[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .msg-success { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .msg-error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .form-box { background: #f8f9fc; padding: 20px; border-radius: 10px; margin-bottom: 30px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: inline-block; width: 150px; font-weight: bold; }
        .form-group select { width: 55%; padding: 8px; border: 1px solid #ccc; border-radius: 5px; }
        .btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; font-size: 14px; }
        .btn-success { background: #28a745; color: white; }
        .btn-warning { background: #ffc107; color: #212529; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-primary { background: #007BFF; color: white; }
        .btn-sm { padding: 4px 10px; font-size: 13px; }
        .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #007BFF; color: white; white-space: nowrap; }
        .action-column { display: flex; flex-direction: column; gap: 4px; align-items: center; }
        .action-column a, .action-column button { width: 100%; text-align: center; padding: 2px 10px; font-size: 13px; }
        .empty-state { padding: 20px; text-align: center; color: #6c757d; }
        .back-link { display: inline-block; margin-top: 20px; }
        .role-badge { display: inline-block; padding: 2px 12px; border-radius: 50px; font-size: 12px; font-weight: bold; }
        .role-admin { background: #dc3545; color: white; }
        .role-user { background: #28a745; color: white; }
        .role-doctor { background: #007BFF; color: white; }
        .role-staff { background: #ffc107; color: #212529; }
    </style>
</head>
<body>
<div class="container">
    <h2>User Management</h2>

    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">✅ User deleted successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['role']) && $_GET['role']=='ok'): ?>
        <div class="msg-success">✅ User role updated successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error">❌ <?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <div class="toolbar">
        <h3>All Users</h3>
        <a href="register.php" class="btn btn-primary">➕ Add New User</a>
    </div>

    <?php if (count($users) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Created</th>
                        <th style="width:200px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                        <tr>
                            <td><?php echo $u['user_id']; ?></td>
                            <td><?php echo htmlspecialchars($u['username']); ?></td>
                            <td><?php echo htmlspecialchars($u['name']); ?></td>
                            <td>
                                <?php
                                $role_class = 'role-user';
                                if ($u['role'] == 'admin') $role_class = 'role-admin';
                                elseif ($u['role'] == 'doctor') $role_class = 'role-doctor';
                                elseif ($u['role'] == 'staff') $role_class = 'role-staff';
                                ?>
                                <span class="role-badge <?php echo $role_class; ?>">
                                    <?php echo strtoupper($u['role']); ?>
                                </span>
                            </td>
                            <td><?php echo date('d-M-Y', strtotime($u['created_at'])); ?></td>
                            <td>
                                <div class="action-column">
                                    <!-- Role Change Form -->
                                    <form method="POST" style="width:100%; margin:0;">
                                        <input type="hidden" name="user_id" value="<?php echo $u['user_id']; ?>">
                                        <select name="role" style="width:100%; padding:4px; font-size:13px; margin-bottom:4px;">
                                            <option value="user" <?php echo ($u['role'] == 'user') ? 'selected' : ''; ?>>User</option>
                                            <option value="admin" <?php echo ($u['role'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
                                            <option value="doctor" <?php echo ($u['role'] == 'doctor') ? 'selected' : ''; ?>>Doctor</option>
                                            <option value="staff" <?php echo ($u['role'] == 'staff') ? 'selected' : ''; ?>>Staff</option>
                                        </select>
                                        <button type="submit" name="update_role" class="btn btn-warning btn-sm" style="width:100%;" <?php echo ($u['user_id'] == $_SESSION['user_id']) ? 'disabled' : ''; ?>>
                                            Change Role
                                        </button>
                                    </form>
                                    <!-- Delete Button -->
                                    <a href="user.php?delete=<?php echo $u['user_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');" <?php echo ($u['user_id'] == $_SESSION['user_id']) ? 'style="pointer-events:none; opacity:0.5;"' : ''; ?>>
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No users found.</div>
    <?php endif; ?>

    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>


