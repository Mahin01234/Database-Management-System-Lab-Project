<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM bed WHERE bed_id = $id");
    if ($del) {
        header("Location: bed.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);   }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['bed_id']);
    $ward_id = intval($_POST['ward_id']);
    $bed_number = trim(mysqli_real_escape_string($conn, $_POST['bed_number']));
    $patient_name = trim(mysqli_real_escape_string($conn, $_POST['patient_name']));
    $admission = !empty($_POST['admission_date']) ? trim(mysqli_real_escape_string($conn, $_POST['admission_date'])) : NULL;
    $discharge = !empty($_POST['discharge_date']) ? trim(mysqli_real_escape_string($conn, $_POST['discharge_date'])) : NULL;
    if ($ward_id == 0 || empty($bed_number)) {
        $msg = "Please select ward and enter bed number.";
    } else {
        $patient_id = NULL;
        if (!empty($patient_name)) {
            $check = mysqli_query($conn, "SELECT patient_id FROM patient WHERE name = '$patient_name'");
            if (mysqli_num_rows($check) > 0) {
                $row = mysqli_fetch_assoc($check);
                $patient_id = $row['patient_id'];
            } else {
                $insert = mysqli_query($conn, "INSERT INTO patient (name, status, registration_date) 
                                               VALUES ('$patient_name', 'Active', NOW())");
                if ($insert) {
                    $patient_id = mysqli_insert_id($conn);
                } else {
                    $msg = "Failed to create new patient: " . mysqli_error($conn);
                    $patient_id = NULL;             }
            }
        }
        if ($id == 0) {
            $sql = "INSERT INTO bed (ward_id, bed_number, patient_id, admission_date, discharge_date)
                    VALUES ($ward_id, '$bed_number', " . ($patient_id ? $patient_id : 'NULL') . ", " . ($admission ? "'$admission'" : "NULL") . ", " . ($discharge ? "'$discharge'" : "NULL") . ")";
        } else {
            $sql = "UPDATE bed SET
                    ward_id = $ward_id,
                    bed_number = '$bed_number',
                    patient_id = " . ($patient_id ? $patient_id : 'NULL') . ",
                    admission_date = " . ($admission ? "'$admission'" : "NULL") . ",
                    discharge_date = " . ($discharge ? "'$discharge'" : "NULL") . "
                    WHERE bed_id = $id";       }
        if (mysqli_query($conn, $sql)) {
            header("Location: bed.php?save=ok");
            exit();
        } else {
            $msg = "Save failed: " . mysqli_error($conn);       }
    }
}
$res = mysqli_query($conn, "SELECT b.bed_id, b.bed_number, b.admission_date, b.discharge_date, 
                                   w.ward_number, w.floor, p.name AS patient_name
                            FROM bed b
                            LEFT JOIN ward w ON b.ward_id = w.ward_id
                            LEFT JOIN patient p ON b.patient_id = p.patient_id
                            ORDER BY b.bed_id ASC");
$beds = [];
if ($res && mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        $beds[] = $row;
    }
} else {
    if ($res === false) {
        $msg = "Fetch failed: " . mysqli_error($conn);   }
}
$edit = null;
if (isset($_GET['edit']) && intval($_GET['edit']) > 0) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT b.*, p.name AS patient_name 
                              FROM bed b
                              LEFT JOIN patient p ON b.patient_id = p.patient_id
                              WHERE b.bed_id = $eid");
    if ($q && mysqli_num_rows($q) > 0) {
        $edit = mysqli_fetch_assoc($q);
    } else {
        $msg = "Edit failed: " . mysqli_error($conn);
        $edit = null;   }
}
$ward_res = mysqli_query($conn, "SELECT ward_id, ward_number, floor FROM ward ORDER BY ward_number");
$wards = [];
while ($w = mysqli_fetch_assoc($ward_res)) {
    $wards[] = $w;   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Beds</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .hint { font-size: 13px; color: #6c757d; margin-left: 5px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Beds</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">Bed saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">Bed deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"> <?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <!-- ===== FORM (NO STATUS) ===== -->
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Bed' : 'Add New Bed'; ?></h3>
        <form method="POST">
            <input type="hidden" name="bed_id" value="<?php echo $edit ? $edit['bed_id'] : 0; ?>">
            <div class="form-group">
                <label>Patient Name</label>
                <input type="text" name="patient_name" 
                       value="<?php echo $edit ? htmlspecialchars($edit['patient_name'] ?? '') : ''; ?>" 
                       autocomplete="off">
                <span class="hint"></span>
            </div>
            <div class="form-group">
                <label>Ward <span class="req"></span></label>
                <select name="ward_id" required>
                    <option value=""></option>
                    <?php foreach ($wards as $w): ?>
                        <option value="<?php echo $w['ward_id']; ?>" 
                            <?php echo ($edit && $edit['ward_id'] == $w['ward_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($w['ward_number'] . ' (Floor ' . $w['floor'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($wards)): ?>
                    <span class="hint" style="color:red;">No wards</span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>Bed Number <span class="req"></span></label>
                <input type="text" name="bed_number" 
                       value="<?php echo $edit ? htmlspecialchars($edit['bed_number']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Admission Date</label>
                <input type="date" name="admission_date" 
                       value="<?php echo $edit && $edit['admission_date'] ? $edit['admission_date'] : ''; ?>">
                <span class="hint"></span>
            </div>
            <div class="form-group">
                <label>Discharge Date</label>
                <input type="date" name="discharge_date" 
                       value="<?php echo $edit && $edit['discharge_date'] ? $edit['discharge_date'] : ''; ?>">
                <span class="hint"></span>
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="bed.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="toolbar">
        <h3>All Beds</h3>
        <a href="bed.php" class="btn btn-primary">Add New</a>
    </div>
    <?php if (count($beds) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ward</th>
                        <th>Bed Number</th>
                        <th>Patient</th>
                        <th>Admission</th>
                        <th>Discharge</th>
                        <th style="width:130px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($beds as $bed): ?>
                        <tr>
                            <td><?php echo $bed['bed_id']; ?></td>
                            <td><?php echo htmlspecialchars($bed['ward_number'] ?? 'N/A') . ' (Floor ' . htmlspecialchars($bed['floor'] ?? '') . ')'; ?></td>
                            <td><?php echo htmlspecialchars($bed['bed_number']); ?></td>
                            <td><?php echo htmlspecialchars($bed['patient_name'] ?? 'N/A'); ?></td>
                            <td><?php echo $bed['admission_date'] ? date('d-M-Y', strtotime($bed['admission_date'])) : 'N/A'; ?></td>
                            <td><?php echo $bed['discharge_date'] ? date('d-M-Y', strtotime($bed['discharge_date'])) : 'N/A'; ?></td>
                            <td>
                                <div class="actions">
                                    <a href="bed.php?edit=<?php echo $bed['bed_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="bed.php?delete=<?php echo $bed['bed_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No beds found. Add one using the form above.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>