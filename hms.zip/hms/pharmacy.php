<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "config.php";
$msg = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $del = mysqli_query($conn, "DELETE FROM pharmacy WHERE pharmacy_id = $id");
    if ($del) {
        header("Location: pharmacy.php?del=ok");
        exit();
    } else {
        $msg = "Delete failed: " . mysqli_error($conn);
    }
}
if (isset($_POST['save'])) {
    $id = intval($_POST['pharmacy_id']);
    $name = trim(mysqli_real_escape_string($conn, $_POST['name']));
    $location = trim(mysqli_real_escape_string($conn, $_POST['location']));
    $contact = trim(mysqli_real_escape_string($conn, $_POST['contact']));
    $email = trim(mysqli_real_escape_string($conn, $_POST['email']));
    $hours = trim(mysqli_real_escape_string($conn, $_POST['working_hours']));
    $pharmacist = trim(mysqli_real_escape_string($conn, $_POST['pharmacist_name']));
    if (empty($name) || empty($location) || empty($contact)) {
        $msg = "Please fill all required fields (Name, Location, Contact).";
    } else {
        if ($id == 0) {
            $sql = "INSERT INTO pharmacy (name, location, contact, email, working_hours, pharmacist_name)
                    VALUES ('$name', '$location', '$contact', '$email', '$hours', '$pharmacist')";
        } else {
            $sql = "UPDATE pharmacy SET
                    name='$name',
                    location='$location',
                    contact='$contact',
                    email='$email',
                    working_hours='$hours',
                    pharmacist_name='$pharmacist'
                    WHERE pharmacy_id=$id";
        }
        if (mysqli_query($conn, $sql)) {
            header("Location: pharmacy.php?save=ok");
            exit();
        } else {
            $msg = "Save failed: " . mysqli_error($conn);
        }
    }
}
$res = mysqli_query($conn, "SELECT * FROM pharmacy ORDER BY pharmacy_id ASC");
$pharmacies = [];
while ($row = mysqli_fetch_assoc($res)) {
    $pharmacies[] = $row;
}
$edit = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $q = mysqli_query($conn, "SELECT * FROM pharmacy WHERE pharmacy_id = $eid");
    if ($q) {
        $edit = mysqli_fetch_assoc($q);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Pharmacies</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .msg-success { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .msg-error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .form-box { background: #f8f9fc; padding: 20px; border-radius: 10px; margin-bottom: 30px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: inline-block; width: 160px; font-weight: bold; }
        .form-group input { width: 55%; padding: 8px; border: 1px solid #ccc; border-radius: 5px; }
        .req { color: red; }
        .btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; font-size: 14px; }
        .btn-success { background: #28a745; color: white; }
        .btn-warning { background: #ffc107; color: #212529; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn-primary { background: #007BFF; color: white; }
        .btn-sm { padding: 4px 10px; font-size: 13px; }
        .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #007BFF; color: white; white-space: nowrap; }
        .actions { display: flex; gap: 5px; } /* পাশাপাশি */
        .empty-state { padding: 20px; text-align: center; color: #6c757d; }
        .back-link { display: inline-block; margin-top: 20px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Pharmacies</h2>
    <?php if (isset($_GET['save']) && $_GET['save']=='ok'): ?>
        <div class="msg-success">Pharmacy saved successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['del']) && $_GET['del']=='ok'): ?>
        <div class="msg-success">Pharmacy deleted successfully!</div>
    <?php endif; ?>
    <?php if ($msg): ?>
        <div class="msg-error"> <?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <div class="form-box">
        <h3><?php echo $edit ? 'Edit Pharmacy' : 'Add New Pharmacy'; ?></h3>
        <form method="POST">
            <input type="hidden" name="pharmacy_id" value="<?php echo $edit ? $edit['pharmacy_id'] : 0; ?>">
            <div class="form-group">
                <label>Pharmacy Name <span class="req"></span></label>
                <input type="text" name="name" value="<?php echo $edit ? htmlspecialchars($edit['name']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Location <span class="req"></span></label>
                <input type="text" name="location" value="<?php echo $edit ? htmlspecialchars($edit['location']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Contact <span class="req"></span></label>
                <input type="text" name="contact" value="<?php echo $edit ? htmlspecialchars($edit['contact']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" value="<?php echo $edit ? htmlspecialchars($edit['email']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Working Hours</label>
                <input type="text" name="working_hours" value="<?php echo $edit ? htmlspecialchars($edit['working_hours']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Pharmacist Name</label>
                <input type="text" name="pharmacist_name" value="<?php echo $edit ? htmlspecialchars($edit['pharmacist_name']) : ''; ?>">
            </div>
            <div>
                <button type="submit" name="save" class="btn btn-success"><?php echo $edit ? 'Update' : 'Save'; ?></button>
                <?php if ($edit): ?>
                    <a href="pharmacy.php" class="btn btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <div class="toolbar">
        <h3>All Pharmacies</h3>
        <a href="pharmacy.php" class="btn btn-primary"> Add New</a>
    </div>
    <?php if (count($pharmacies) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>Working Hours</th>
                        <th>Pharmacist</th>
                        <th style="width:130px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pharmacies as $ph): ?>
                        <tr>
                            <td><?php echo $ph['pharmacy_id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($ph['name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($ph['location']); ?></td>
                            <td><?php echo htmlspecialchars($ph['contact']); ?></td>
                            <td><?php echo htmlspecialchars($ph['email']); ?></td>
                            <td><?php echo htmlspecialchars($ph['working_hours']); ?></td>
                            <td><?php echo htmlspecialchars($ph['pharmacist_name']); ?></td>
                            <td>
                                <div class="actions">
                                    <a href="pharmacy.php?edit=<?php echo $ph['pharmacy_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="pharmacy.php?delete=<?php echo $ph['pharmacy_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">No pharmacies found. Add one using the form above.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>