<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include "config.php";

mysqli_report(MYSQLI_REPORT_OFF);

$msg = "";

$active_tab = $_GET['tab'] ?? 'donors';

if (!in_array($active_tab, ['donors', 'requests'], true)) {
    $active_tab = 'donors';
}

$groups = [
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-',
    'O+',
    'O-'
];


/* =========================================================
   HELPER FUNCTIONS
========================================================= */

function clean($value)
{
    return trim((string)$value);
}

function esc($conn, $value)
{
    return mysqli_real_escape_string(
        $conn,
        clean($value)
    );
}

function redirectTo($url)
{
    header("Location: " . $url);
    exit();
}


/* =========================================================
   DELETE DONOR
========================================================= */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['action'] ?? '') === 'delete_donor'
) {

    $id = intval($_POST['donor_id'] ?? 0);

    if ($id > 0) {

        $sql = "
            DELETE FROM blood_donor
            WHERE donor_id = $id
        ";

        if (mysqli_query($conn, $sql)) {

            redirectTo(
                "blood_bank.php?tab=donors&del=ok"
            );

        } else {

            $msg =
                "Donor delete failed: " .
                mysqli_error($conn);
        }

    } else {

        $msg = "Invalid donor ID.";
    }
}


/* =========================================================
   DELETE REQUEST
========================================================= */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['action'] ?? '') === 'delete_request'
) {

    $id = intval($_POST['request_id'] ?? 0);

    if ($id > 0) {

        $sql = "
            DELETE FROM blood_request
            WHERE request_id = $id
        ";

        if (mysqli_query($conn, $sql)) {

            redirectTo(
                "blood_bank.php?tab=requests&del=ok"
            );

        } else {

            $msg =
                "Request delete failed: " .
                mysqli_error($conn);
        }

    } else {

        $msg = "Invalid request ID.";
    }
}


/* =========================================================
   SAVE / UPDATE DONOR
========================================================= */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['action'] ?? '') === 'save_donor'
) {

    $id = intval(
        $_POST['donor_id'] ?? 0
    );

    $name = clean(
        $_POST['name'] ?? ''
    );

    $blood_group = strtoupper(
        clean($_POST['blood_group'] ?? '')
    );

    $contact = clean(
        $_POST['contact'] ?? ''
    );

    $phone = clean(
        $_POST['phone'] ?? ''
    );

    $email = clean(
        $_POST['email'] ?? ''
    );

    $address = clean(
        $_POST['address'] ?? ''
    );

    $district = clean(
        $_POST['district'] ?? ''
    );

    $last_donation = clean(
        $_POST['last_donation_date'] ?? ''
    );

    $status = clean(
        $_POST['status'] ?? 'Active'
    );


    /* =====================================================
       VALIDATION
    ===================================================== */

    if (
        $name === '' ||
        $blood_group === '' ||
        $contact === '' ||
        $phone === '' ||
        $district === ''
    ) {

        $msg =
            "Please fill all required fields.";

    } elseif (
        !preg_match(
            '/^[0-9]{11}$/',
            $contact
        )
    ) {

        $msg =
            "Contact must be exactly 11 digits.";

    } elseif (
        !preg_match(
            '/^[0-9]{11}$/',
            $phone
        )
    ) {

        $msg =
            "Phone must be exactly 11 digits.";

    } elseif (
        !in_array(
            $blood_group,
            $groups,
            true
        )
    ) {

        $msg =
            "Invalid blood group.";

    } elseif (
        !in_array(
            $status,
            ['Active', 'Inactive'],
            true
        )
    ) {

        $msg =
            "Invalid donor status.";

    } else {

        $name = esc(
            $conn,
            $name
        );

        $blood_group = esc(
            $conn,
            $blood_group
        );

        $contact = esc(
            $conn,
            $contact
        );

        $phone = esc(
            $conn,
            $phone
        );

        $email = esc(
            $conn,
            $email
        );

        $address = esc(
            $conn,
            $address
        );

        $district = esc(
            $conn,
            $district
        );

        $status = esc(
            $conn,
            $status
        );


        if ($last_donation !== '') {

            $last_donation = esc(
                $conn,
                $last_donation
            );

            $lastDonationSql =
                "'$last_donation'";

        } else {

            $lastDonationSql = "NULL";
        }


        /* =================================================
           UPDATE DONOR
        ================================================= */

        if ($id > 0) {

            $sql = "
                UPDATE blood_donor
                SET
                    name = '$name',
                    blood_group = '$blood_group',
                    contact = '$contact',
                    phone = '$phone',
                    email = '$email',
                    address = '$address',
                    district = '$district',
                    last_donation_date =
                        $lastDonationSql,
                    status = '$status'
                WHERE donor_id = $id
            ";

            if (mysqli_query($conn, $sql)) {

                redirectTo(
                    "blood_bank.php?tab=donors&save=updated"
                );

            } else {

                $msg =
                    "Donor update failed: " .
                    mysqli_error($conn);
            }


        /* =================================================
           INSERT DONOR
        ================================================= */

        } else {

            $sql = "
                INSERT INTO blood_donor
                (
                    name,
                    blood_group,
                    contact,
                    phone,
                    email,
                    address,
                    district,
                    last_donation_date,
                    status
                )
                VALUES
                (
                    '$name',
                    '$blood_group',
                    '$contact',
                    '$phone',
                    '$email',
                    '$address',
                    '$district',
                    $lastDonationSql,
                    '$status'
                )
            ";

            if (mysqli_query($conn, $sql)) {

                redirectTo(
                    "blood_bank.php?tab=donors&save=added"
                );

            } else {

                $msg =
                    "Donor save failed: " .
                    mysqli_error($conn);
            }
        }
    }
}


/* =========================================================
   SAVE / UPDATE REQUEST
========================================================= */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['action'] ?? '') === 'save_request'
) {

    $id = intval(
        $_POST['request_id'] ?? 0
    );

    $patient_name = clean(
        $_POST['patient_name'] ?? ''
    );

    $blood_group = strtoupper(
        clean($_POST['blood_group'] ?? '')
    );

    $quantity = intval(
        $_POST['quantity'] ?? 0
    );

    $hospital = clean(
        $_POST['hospital'] ?? ''
    );

    $district = clean(
        $_POST['district'] ?? ''
    );

    $contact = clean(
        $_POST['contact'] ?? ''
    );

    $phone = clean(
        $_POST['phone'] ?? ''
    );

    $request_date = clean(
        $_POST['request_date'] ?? ''
    );

    $status = clean(
        $_POST['status'] ?? 'Pending'
    );

    $notes = clean(
        $_POST['notes'] ?? ''
    );


    /* =====================================================
       VALIDATION
    ===================================================== */

    if (
        $patient_name === '' ||
        $blood_group === '' ||
        $quantity <= 0 ||
        $request_date === '' ||
        $district === '' ||
        $contact === '' ||
        $phone === ''
    ) {

        $msg =
            "Please fill all required fields.";

    } elseif (
        !preg_match(
            '/^[0-9]{11}$/',
            $contact
        )
    ) {

        $msg =
            "Contact must be exactly 11 digits.";

    } elseif (
        !preg_match(
            '/^[0-9]{11}$/',
            $phone
        )
    ) {

        $msg =
            "Phone must be exactly 11 digits.";

    } elseif (
        !in_array(
            $blood_group,
            $groups,
            true
        )
    ) {

        $msg =
            "Invalid blood group.";

    } elseif (
        !in_array(
            $status,
            [
                'Pending',
                'Fulfilled',
                'Cancelled'
            ],
            true
        )
    ) {

        $msg =
            "Invalid request status.";

    } else {

        $patient_name = esc(
            $conn,
            $patient_name
        );

        $blood_group = esc(
            $conn,
            $blood_group
        );

        $hospital = esc(
            $conn,
            $hospital
        );

        $district = esc(
            $conn,
            $district
        );

        $contact = esc(
            $conn,
            $contact
        );

        $phone = esc(
            $conn,
            $phone
        );

        $request_date = esc(
            $conn,
            $request_date
        );

        $status = esc(
            $conn,
            $status
        );

        $notes = esc(
            $conn,
            $notes
        );


        /* =================================================
           UPDATE REQUEST
        ================================================= */

        if ($id > 0) {

            $sql = "
                UPDATE blood_request
                SET
                    patient_name = '$patient_name',
                    blood_group = '$blood_group',
                    quantity = $quantity,
                    hospital = '$hospital',
                    district = '$district',
                    contact = '$contact',
                    phone = '$phone',
                    request_date = '$request_date',
                    status = '$status',
                    notes = '$notes'
                WHERE request_id = $id
            ";

            if (mysqli_query($conn, $sql)) {

                redirectTo(
                    "blood_bank.php?tab=requests&save=updated"
                );

            } else {

                $msg =
                    "Request update failed: " .
                    mysqli_error($conn);
            }


        /* =================================================
           INSERT REQUEST
        ================================================= */

        } else {

            $sql = "
                INSERT INTO blood_request
                (
                    patient_name,
                    blood_group,
                    quantity,
                    hospital,
                    district,
                    contact,
                    phone,
                    request_date,
                    status,
                    notes
                )
                VALUES
                (
                    '$patient_name',
                    '$blood_group',
                    $quantity,
                    '$hospital',
                    '$district',
                    '$contact',
                    '$phone',
                    '$request_date',
                    '$status',
                    '$notes'
                )
            ";

            if (mysqli_query($conn, $sql)) {

                redirectTo(
                    "blood_bank.php?tab=requests&save=added"
                );

            } else {

                $msg =
                    "Request save failed: " .
                    mysqli_error($conn);
            }
        }
    }
}


/* =========================================================
   SEARCH / FILTER DONORS
========================================================= */

$search_group = strtoupper(
    clean($_GET['search_group'] ?? '')
);

$donors = [];


if (
    $search_group !== '' &&
    in_array(
        $search_group,
        $groups,
        true
    )
) {

    $safeGroup = esc(
        $conn,
        $search_group
    );

    $sql = "
        SELECT *
        FROM blood_donor
        WHERE
            UPPER(TRIM(blood_group))
                = '$safeGroup'
        ORDER BY donor_id DESC
    ";

} else {

    $sql = "
        SELECT *
        FROM blood_donor
        ORDER BY donor_id DESC
    ";
}


$res = mysqli_query(
    $conn,
    $sql
);

if ($res) {

    while (
        $row =
            mysqli_fetch_assoc($res)
    ) {

        $donors[] = $row;
    }
}


/* =========================================================
   LOAD REQUESTS
========================================================= */

$requests = [];

$res = mysqli_query(
    $conn,
    "
    SELECT *
    FROM blood_request
    ORDER BY request_id DESC
    "
);

if ($res) {

    while (
        $row =
            mysqli_fetch_assoc($res)
    ) {

        $requests[] = $row;
    }
}


/* =========================================================
   CURRENT BLOOD STOCK
=========================================================

   IMPORTANT:

   ACTIVE + INACTIVE BOTH COUNT

   Example:

   O+ Active     = 1
   O+ Inactive   = 1

   Current Stock = 2

========================================================= */

$stock = [];


foreach ($groups as $g) {

    $safeGroup = esc(
        $conn,
        strtoupper(
            trim($g)
        )
    );


    /*
     * IMPORTANT:
     *
     * এখানে status condition নেই।
     *
     * তাই Active এবং Inactive
     * উভয় donor count হবে।
     */

    $sql = "
        SELECT COUNT(*) AS total
        FROM blood_donor
        WHERE
            UPPER(TRIM(blood_group))
                = '$safeGroup'
    ";


    $q = mysqli_query(
        $conn,
        $sql
    );


    if ($q) {

        $row =
            mysqli_fetch_assoc($q);

        $stock[$g] = intval(
            $row['total'] ?? 0
        );

    } else {

        $stock[$g] = 0;
    }
}


/* =========================================================
   EDIT DONOR
========================================================= */

$edit_donor = null;


if (isset($_GET['edit_donor'])) {

    $id = intval(
        $_GET['edit_donor']
    );

    if ($id > 0) {

        $q = mysqli_query(
            $conn,
            "
            SELECT *
            FROM blood_donor
            WHERE donor_id = $id
            LIMIT 1
            "
        );

        if (
            $q &&
            mysqli_num_rows($q) > 0
        ) {

            $edit_donor =
                mysqli_fetch_assoc($q);
        }
    }
}


/* =========================================================
   EDIT REQUEST
========================================================= */

$edit_request = null;


if (isset($_GET['edit_request'])) {

    $id = intval(
        $_GET['edit_request']
    );

    if ($id > 0) {

        $q = mysqli_query(
            $conn,
            "
            SELECT *
            FROM blood_request
            WHERE request_id = $id
            LIMIT 1
            "
        );

        if (
            $q &&
            mysqli_num_rows($q) > 0
        ) {

            $edit_request =
                mysqli_fetch_assoc($q);
        }
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    Blood Bank Management
</title>

<link
    rel="stylesheet"
    href="style.css"
>


<style>

/* =========================================================
   BLOOD STOCK
========================================================= */

.blood-stock-grid {

    display: grid;

    grid-template-columns:
        repeat(8, 1fr);

    gap: 12px;

    margin:
        20px 0 30px;
}


.blood-stock-card {

    background: #f8f9fc;

    border-radius: 12px;

    padding:
        12px 8px;

    text-align: center;

    border-left:
        5px solid #dc3545;

    box-shadow:
        0 2px 8px
        rgba(0,0,0,.06);

    transition: .3s;
}


.blood-stock-card:hover {

    transform:
        translateY(-4px);

    box-shadow:
        0 6px 16px
        rgba(220,53,69,.15);
}


.blood-stock-card .group {

    font-size: 20px;

    font-weight: 800;

    color: #dc3545;
}


.blood-stock-card .count {

    font-size: 18px;

    font-weight: 700;

    color: #003366;

    margin-top: 3px;
}


.blood-stock-card .label {

    font-size: 10px;

    font-weight: 600;

    margin-top: 4px;
}


.label-available {

    color: #28a745;
}


.label-notavailable {

    color: #dc3545;
}


/* =========================================================
   TABS
========================================================= */

.tab-bar {

    display: flex;

    gap: 10px;

    margin-bottom: 25px;

    border-bottom:
        2px solid #dee2e6;

    padding-bottom: 10px;
}


.tab-bar a {

    padding:
        8px 22px;

    border-radius: 30px;

    text-decoration: none;

    font-weight: 600;

    background: #e9ecef;

    color: #495057;

    transition: .3s;
}


.tab-bar a.active {

    background: #007BFF;

    color: white;
}


.tab-bar a:hover:not(.active) {

    background: #dee2e6;
}


/* =========================================================
   FORM
========================================================= */

.form-row-inline {

    display: flex;

    flex-wrap: wrap;

    gap: 15px;

    align-items: center;
}


.form-row-inline .form-group {

    flex:
        1 1 180px;
}


/* =========================================================
   STATUS
========================================================= */

.badge-status {

    padding:
        4px 12px;

    border-radius: 50px;

    font-size: 12px;

    font-weight: 600;

    display: inline-block;
}


.badge-pending {

    background: #ffc107;

    color: #212529;
}


.badge-fulfilled {

    background: #28a745;

    color: white;
}


.badge-cancelled {

    background: #dc3545;

    color: white;
}


.badge-active {

    background: #28a745;

    color: white;
}


.badge-inactive {

    background: #6c757d;

    color: white;
}


/* =========================================================
   ACTION
========================================================= */

.action-column {

    display: flex;

    flex-direction: column;

    gap: 4px;

    align-items: center;
}


.action-column form {

    margin: 0;

    width: 100%;
}


.action-column a,
.action-column button {

    width: 100%;

    text-align: center;

    padding:
        3px 8px;

    font-size: 12px;

    box-sizing: border-box;
}


/* =========================================================
   DISTRICT
========================================================= */

.district-search-wrapper {

    position: relative;

    width: 100%;
}


.district-list {

    position: absolute;

    top: 100%;

    left: 0;

    right: 0;

    background: #fff;

    border:
        1px solid #ccc;

    border-top: none;

    max-height: 200px;

    overflow-y: auto;

    z-index: 999;

    display: none;

    list-style: none;

    padding: 0;

    margin: 0;
}


.district-list li {

    padding:
        8px 12px;

    cursor: pointer;

    border-bottom:
        1px solid #eee;
}


.district-list li:hover {

    background: #007BFF;

    color: #fff;
}


/* =========================================================
   PHONE
========================================================= */

.phone-error {

    color: #dc3545;

    font-size: 13px;

    margin-top: 4px;

    display: none;
}


.phone-error.show {

    display: block;
}


.phone-input {

    width: 100%;
}


.phone-input.valid {

    border-color:
        #28a745 !important;
}


.phone-input.invalid {

    border-color:
        #dc3545 !important;
}


/* =========================================================
   SEARCH
========================================================= */

.search-box {

    display: flex;

    gap: 10px;

    align-items: center;

    margin-bottom: 15px;

    flex-wrap: wrap;
}


.search-box select {

    padding:
        8px 14px;

    border:
        1px solid #ced4da;

    border-radius: 6px;

    font-size: 15px;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:1000px) {

    .blood-stock-grid {

        grid-template-columns:
            repeat(4,1fr);
    }
}


@media(max-width:600px) {

    .blood-stock-grid {

        grid-template-columns:
            repeat(2,1fr);
    }


    .tab-bar {

        flex-wrap: wrap;
    }


    .tab-bar a {

        flex: 1;

        text-align: center;

        padding:
            6px 12px;

        font-size: 14px;
    }


    .form-row-inline .form-group {

        flex:
            1 1 100%;
    }
}

</style>

</head>


<body>

<div class="container">


<!-- =========================================================
     PAGE TITLE
========================================================= -->

<h2>
    🩸 Blood Bank Management
</h2>


<!-- =========================================================
     SUCCESS MESSAGE
========================================================= -->

<?php if (isset($_GET['save'])): ?>

    <?php if ($_GET['save'] === 'added'): ?>

        <div class="msg-success">
            ✅ Record added successfully!
        </div>

    <?php elseif ($_GET['save'] === 'updated'): ?>

        <div class="msg-success">
            ✅ Record updated successfully!
        </div>

    <?php endif; ?>

<?php endif; ?>


<!-- =========================================================
     DELETE MESSAGE
========================================================= -->

<?php if (
    isset($_GET['del']) &&
    $_GET['del'] === 'ok'
): ?>

<div class="msg-success">

    ✅ Record deleted successfully!

</div>

<?php endif; ?>


<!-- =========================================================
     ERROR MESSAGE
========================================================= -->

<?php if ($msg !== ''): ?>

<div class="msg-error">

    ❌
    <?= htmlspecialchars($msg) ?>

</div>

<?php endif; ?>


<!-- =========================================================
     CURRENT BLOOD STOCK
     
     ONLY DONORS TAB
========================================================= -->

<?php if ($active_tab === 'donors'): ?>

<h3>
    📊 Current Blood Stock
</h3>


<div class="blood-stock-grid">

<?php foreach ($groups as $g): ?>

    <?php

    $currentStock =
        (int)($stock[$g] ?? 0);

    ?>


    <div class="blood-stock-card">


        <div class="group">

            <?= htmlspecialchars($g) ?>

        </div>


        <div class="count">

            <?= $currentStock ?>

        </div>


        <div
            class="
                label
                <?= $currentStock > 0
                    ? 'label-available'
                    : 'label-notavailable'
                ?>
            "
        >

            <?= $currentStock > 0
                ? '✅ Available'
                : '❌ Not Available'
            ?>

        </div>


    </div>

<?php endforeach; ?>

</div>

<?php endif; ?>


<!-- =========================================================
     TABS
========================================================= -->

<div class="tab-bar">


<a
    href="blood_bank.php?tab=donors"
    class="<?= $active_tab === 'donors'
        ? 'active'
        : ''
    ?>"
>

    👤 Donors

</a>


<a
    href="blood_bank.php?tab=requests"
    class="<?= $active_tab === 'requests'
        ? 'active'
        : ''
    ?>"
>

    📋 Requests

</a>


</div>


<?php if ($active_tab === 'donors'): ?>


<!-- =========================================================
     DONOR FORM
========================================================= -->

<div class="form-box">

<h3>

    <?= $edit_donor
        ? 'Edit Donor'
        : 'Add New Donor'
    ?>

</h3>


<form
    method="POST"
    id="donorForm"
    onsubmit="return validateDonorForm()"
>


<input
    type="hidden"
    name="action"
    value="save_donor"
>


<input
    type="hidden"
    name="donor_id"
    value="<?= $edit_donor
        ? intval(
            $edit_donor['donor_id']
        )
        : 0
    ?>"
>


<!-- ROW 1 -->

<div class="form-row-inline">


<div class="form-group">

<label>

    Full Name
    <span class="req"></span>

</label>


<input
    type="text"
    name="name"
    value="<?= $edit_donor
        ? htmlspecialchars(
            $edit_donor['name']
        )
        : ''
    ?>"
    required
>

</div>


<div class="form-group">

<label>

    Blood Group
    <span class="req"></span>

</label>


<select
    name="blood_group"
    required
>

<option value="">
    Select
</option>


<?php foreach ($groups as $g): ?>

<option
    value="<?= htmlspecialchars($g) ?>"
    <?= (
        $edit_donor &&
        strtoupper(
            trim(
                $edit_donor['blood_group']
            )
        ) === $g
    )
        ? 'selected'
        : ''
    ?>
>

    <?= htmlspecialchars($g) ?>

</option>

<?php endforeach; ?>

</select>

</div>


<div class="form-group">

<label>

    Contact
    <span class="req"></span>

</label>


<input
    type="text"
    name="contact"
    id="donorContact"
    class="phone-input"
    value="<?= $edit_donor
        ? htmlspecialchars(
            $edit_donor['contact']
        )
        : ''
    ?>"
    maxlength="11"
    minlength="11"
    pattern="[0-9]{11}"
    inputmode="numeric"
    required
>


<div
    class="phone-error"
    id="donorContactError"
>

     Exactly 11 digits required.

</div>

</div>

</div>


<!-- ROW 2 -->

<div class="form-row-inline">


<div class="form-group">

<label>

    Phone
    <span class="req"></span>

</label>


<input
    type="text"
    name="phone"
    id="donorPhone"
    class="phone-input"
    value="<?= $edit_donor
        ? htmlspecialchars(
            $edit_donor['phone'] ?? ''
        )
        : ''
    ?>"
    maxlength="11"
    minlength="11"
    pattern="[0-9]{11}"
    inputmode="numeric"
    required
>


<div
    class="phone-error"
    id="donorPhoneError"
>

     Exactly 11 digits required.

</div>

</div>


<div class="form-group">

<label>
    Email
</label>


<input
    type="email"
    name="email"
    value="<?= $edit_donor
        ? htmlspecialchars(
            $edit_donor['email'] ?? ''
        )
        : ''
    ?>"
>

</div>


<div class="form-group">

<label>
    Address
</label>


<input
    type="text"
    name="address"
    value="<?= $edit_donor
        ? htmlspecialchars(
            $edit_donor['address'] ?? ''
        )
        : ''
    ?>"
>

</div>

</div>


<!-- ROW 3 -->

<div class="form-row-inline">


<div class="form-group">

<label>
    Last Donation
</label>


<input
    type="date"
    name="last_donation_date"
    value="<?= (
        $edit_donor &&
        !empty(
            $edit_donor['last_donation_date']
        )
    )
        ? htmlspecialchars(
            $edit_donor['last_donation_date']
        )
        : ''
    ?>"
>

</div>


<div class="form-group">

<label>
    Country
</label>


<input
    type="text"
    value="Bangladesh"
    readonly
    style="
        background:#e9ecef;
        cursor:not-allowed
    "
>

</div>


<div
    class="form-group"
    style="flex:2"
>

<label>

    District
    <span class="req"></span>

</label>


<div class="district-search-wrapper">


<input
    type="text"
    id="districtInput"
    name="district"
    placeholder="search..."
    value="<?= $edit_donor
        ? htmlspecialchars(
            $edit_donor['district'] ?? ''
        )
        : ''
    ?>"
    autocomplete="off"
    required
>


<ul
    id="districtList"
    class="district-list"
></ul>


</div>

</div>

</div>


<!-- ROW 4 -->

<div class="form-row-inline">


<div class="form-group">

<label>
    Status
</label>


<select name="status">


<option
    value="Active"
    <?= (
        !$edit_donor ||
        ($edit_donor['status'] ?? '')
            === 'Active'
    )
        ? 'selected'
        : ''
    ?>
>

    Active

</option>


<option
    value="Inactive"
    <?= (
        $edit_donor &&
        ($edit_donor['status'] ?? '')
            === 'Inactive'
    )
        ? 'selected'
        : ''
    ?>
>

    Inactive

</option>


</select>

</div>


<div
    class="form-group"
    style="
        display:flex;
        gap:10px;
        align-items:center;
        padding-top:8px
    "
>


<button
    type="submit"
    class="btn btn-success"
>

    <?= $edit_donor
        ? 'Update'
        : 'Save'
    ?>

</button>


<?php if ($edit_donor): ?>

<a
    href="blood_bank.php?tab=donors"
    class="btn btn-secondary"
>

    Cancel

</a>

<?php endif; ?>


</div>

</div>

</form>

</div>


<!-- =========================================================
     DONOR TOOLBAR
========================================================= -->

<div class="toolbar">

<h3>
    All Donors
</h3>


<a
    href="blood_bank.php?tab=donors"
    class="btn btn-primary"
>

    Add New

</a>

</div>


<!-- =========================================================
     BLOOD GROUP FILTER
========================================================= -->

<div class="search-box">

<strong>
    Filter by Blood Group:
</strong>


<select
    id="searchGroup"
    onchange="filterBloodGroup(this.value)"
>

<option value="">
    All Groups
</option>


<?php foreach ($groups as $g): ?>

<option
    value="<?= htmlspecialchars($g) ?>"
    <?= $search_group === $g
        ? 'selected'
        : ''
    ?>
>

    <?= htmlspecialchars($g) ?>

</option>

<?php endforeach; ?>

</select>


<?php if ($search_group !== ''): ?>

<a
    href="blood_bank.php?tab=donors"
    class="btn btn-secondary btn-sm"
>

    Clear Filter

</a>

<?php endif; ?>

</div>


<!-- =========================================================
     NO FILTERED DONOR
========================================================= -->

<?php if (
    $search_group !== '' &&
    count($donors) === 0
): ?>

<div class="no-donor">

    <?= htmlspecialchars(
        $search_group
    ) ?>

    There is no donor for this blood group.

</div>

<?php endif; ?>


<!-- =========================================================
     DONOR TABLE
========================================================= -->

<?php if (count($donors) > 0): ?>

<div class="table-responsive">

<table>

<thead>

<tr>

<th>ID</th>
<th>Name</th>
<th>Blood Group</th>
<th>Contact</th>
<th>Phone</th>
<th>Email</th>
<th>Address</th>
<th>District</th>
<th>Last Donation</th>
<th>Status</th>
<th>Actions</th>

</tr>

</thead>


<tbody>

<?php foreach ($donors as $d): ?>

<tr>


<td>

    <?= intval(
        $d['donor_id']
    ) ?>

</td>


<td>

<strong>

    <?= htmlspecialchars(
        $d['name']
    ) ?>

</strong>

</td>


<td>

<strong
    style="color:#dc3545"
>

    <?= htmlspecialchars(
        strtoupper(
            trim(
                $d['blood_group']
            )
        )
    ) ?>

</strong>

</td>


<td>

    <?= htmlspecialchars(
        $d['contact'] ?? ''
    ) ?>

</td>


<td>

    <?= htmlspecialchars(
        $d['phone'] ?? ''
    ) ?>

</td>


<td>

    <?= htmlspecialchars(
        $d['email'] ?? ''
    ) ?>

</td>


<td>

    <?= htmlspecialchars(
        $d['address'] ?? ''
    ) ?>

</td>


<td>

    <?= htmlspecialchars(
        $d['district'] ?? ''
    ) ?>

</td>


<td>

<?= !empty(
    $d['last_donation_date']
)
    ? date(
        'd-M-Y',
        strtotime(
            $d['last_donation_date']
        )
    )
    : 'N/A'
?>

</td>


<td>

<span
    class="
        badge-status
        <?= strtolower(
            trim(
                $d['status'] ?? ''
            )
        ) === 'active'
            ? 'badge-active'
            : 'badge-inactive'
        ?>
    "
>

    <?= htmlspecialchars(
        $d['status'] ?? ''
    ) ?>

</span>

</td>


<td>

<div class="action-column">


<a
    href="blood_bank.php?edit_donor=<?= intval(
        $d['donor_id']
    ) ?>&tab=donors"
    class="btn btn-warning btn-sm"
>

    Edit

</a>


<form
    method="POST"
    onsubmit="
        return confirm(
            'Are you sure you want to delete this donor?'
        );
    "
>


<input
    type="hidden"
    name="action"
    value="delete_donor"
>


<input
    type="hidden"
    name="donor_id"
    value="<?= intval(
        $d['donor_id']
    ) ?>"
>


<button
    type="submit"
    class="btn btn-danger btn-sm"
>

    Delete

</button>


</form>


</div>

</td>


</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>


<?php elseif ($search_group === ''): ?>

<div class="empty-state">

    No donors found.
    Add one using the form above.

</div>

<?php endif; ?>


<!-- =========================================================
     REQUESTS TAB
========================================================= -->

<?php elseif ($active_tab === 'requests'): ?>


<!-- =========================================================
     REQUEST FORM
========================================================= -->

<div class="form-box">

<h3>

<?= $edit_request
    ? 'Edit Request'
    : 'Add New Blood Request'
?>

</h3>


<form
    method="POST"
    id="requestForm"
    onsubmit="return validateRequestForm()"
>


<input
    type="hidden"
    name="action"
    value="save_request"
>


<input
    type="hidden"
    name="request_id"
    value="<?= $edit_request
        ? intval(
            $edit_request['request_id']
        )
        : 0
    ?>"
>


<!-- ROW 1 -->

<div class="form-row-inline">


<div class="form-group">

<label>

    Patient Name
    <span class="req"></span>

</label>


<input
    type="text"
    name="patient_name"
    value="<?= $edit_request
        ? htmlspecialchars(
            $edit_request['patient_name']
        )
        : ''
    ?>"
    required
>

</div>


<div class="form-group">

<label>

    Blood Group
    <span class="req"></span>

</label>


<select
    name="blood_group"
    required
>

<option value="">
    Select
</option>


<?php foreach ($groups as $g): ?>

<option
    value="<?= htmlspecialchars($g) ?>"
    <?= (
        $edit_request &&
        strtoupper(
            trim(
                $edit_request['blood_group']
            )
        ) === $g
    )
        ? 'selected'
        : ''
    ?>
>

    <?= htmlspecialchars($g) ?>

</option>

<?php endforeach; ?>

</select>

</div>


<div class="form-group">

<label>

    Units
    <span class="req"></span>

</label>


<input
    type="number"
    name="quantity"
    value="<?= $edit_request
        ? intval(
            $edit_request['quantity']
        )
        : ''
    ?>"
    min="1"
    required
>

</div>

</div>


<!-- ROW 2 -->

<div class="form-row-inline">


<div class="form-group">

<label>
    Hospital
</label>


<input
    type="text"
    name="hospital"
    value="<?= $edit_request
        ? htmlspecialchars(
            $edit_request['hospital'] ?? ''
        )
        : ''
    ?>"
>

</div>


<div class="form-group">

<label>

    Contact
    <span class="req"></span>

</label>


<input
    type="text"
    name="contact"
    id="requestContact"
    class="phone-input"
    value="<?= $edit_request
        ? htmlspecialchars(
            $edit_request['contact'] ?? ''
        )
        : ''
    ?>"
    maxlength="11"
    minlength="11"
    pattern="[0-9]{11}"
    inputmode="numeric"
    required
>


<div
    class="phone-error"
    id="requestContactError"
>

     Exactly 11 digits required.

</div>

</div>


<div class="form-group">

<label>

    Phone
    <span class="req"></span>

</label>


<input
    type="text"
    name="phone"
    id="requestPhone"
    class="phone-input"
    value="<?= $edit_request
        ? htmlspecialchars(
            $edit_request['phone'] ?? ''
        )
        : ''
    ?>"
    maxlength="11"
    minlength="11"
    pattern="[0-9]{11}"
    inputmode="numeric"
    required
>


<div
    class="phone-error"
    id="requestPhoneError"
>

     Exactly 11 digits required.

</div>

</div>

</div>


<!-- ROW 3 -->

<div class="form-row-inline">


<div class="form-group">

<label>

    Request Date
    <span class="req"></span>

</label>


<input
    type="date"
    name="request_date"
    value="<?= $edit_request
        ? htmlspecialchars(
            $edit_request['request_date']
        )
        : date('Y-m-d')
    ?>"
    required
>

</div>


<div class="form-group">

<label>
    Country
</label>


<input
    type="text"
    value="Bangladesh"
    readonly
    style="
        background:#e9ecef;
        cursor:not-allowed
    "
>

</div>


<div
    class="form-group"
    style="flex:2"
>

<label>

    District
    <span class="req"></span>

</label>


<div class="district-search-wrapper">


<input
    type="text"
    id="districtInputReq"
    name="district"
    placeholder="Type to search..."
    value="<?= $edit_request
        ? htmlspecialchars(
            $edit_request['district'] ?? ''
        )
        : ''
    ?>"
    autocomplete="off"
    required
>


<ul
    id="districtListReq"
    class="district-list"
></ul>


</div>

</div>

</div>


<!-- ROW 4 -->

<div class="form-row-inline">


<div class="form-group">

<label>
    Status
</label>


<select name="status">


<option
    value="Pending"
    <?= (
        !$edit_request ||
        ($edit_request['status'] ?? '')
            === 'Pending'
    )
        ? 'selected'
        : ''
    ?>
>

    Pending

</option>


<option
    value="Fulfilled"
    <?= (
        $edit_request &&
        ($edit_request['status'] ?? '')
            === 'Fulfilled'
    )
        ? 'selected'
        : ''
    ?>
>

    Fulfilled

</option>


<option
    value="Cancelled"
    <?= (
        $edit_request &&
        ($edit_request['status'] ?? '')
            === 'Cancelled'
    )
        ? 'selected'
        : ''
    ?>
>

    Cancelled

</option>


</select>

</div>


<div
    class="form-group"
    style="flex:2"
>

<label>
    Notes
</label>


<textarea
    name="notes"
    rows="1"
><?= $edit_request
    ? htmlspecialchars(
        $edit_request['notes'] ?? ''
    )
    : ''
?></textarea>


</div>


<div
    class="form-group"
    style="
        display:flex;
        gap:10px;
        align-items:center
    "
>


<button
    type="submit"
    class="btn btn-success"
>

    <?= $edit_request
        ? 'Update'
        : 'Save'
    ?>

</button>


<?php if ($edit_request): ?>

<a
    href="blood_bank.php?tab=requests"
    class="btn btn-secondary"
>

    Cancel

</a>

<?php endif; ?>


</div>

</div>

</form>

</div>


<!-- =========================================================
     REQUEST TOOLBAR
========================================================= -->

<div class="toolbar">

<h3>

     All Blood Requests

</h3>


<a
    href="blood_bank.php?tab=requests"
    class="btn btn-primary"
>

    Add New

</a>

</div>


<!-- =========================================================
     REQUEST TABLE
========================================================= -->

<?php if (count($requests) > 0): ?>

<div class="table-responsive">

<table>

<thead>

<tr>

<th>ID</th>
<th>Patient</th>
<th>Blood Group</th>
<th>Units</th>
<th>Hospital</th>
<th>District</th>
<th>Contact</th>
<th>Phone</th>
<th>Request Date</th>
<th>Status</th>
<th>Notes</th>
<th>Actions</th>

</tr>

</thead>


<tbody>

<?php foreach ($requests as $r): ?>

<tr>


<td>

    <?= intval(
        $r['request_id']
    ) ?>

</td>


<td>

<strong>

    <?= htmlspecialchars(
        $r['patient_name']
    ) ?>

</strong>

</td>


<td>

<strong
    style="color:#dc3545"
>

    <?= htmlspecialchars(
        strtoupper(
            trim(
                $r['blood_group']
            )
        )
    ) ?>

</strong>

</td>


<td>

    <?= intval(
        $r['quantity']
    ) ?>

</td>


<td>

    <?= htmlspecialchars(
        $r['hospital'] ?? ''
    ) ?>

</td>


<td>

    <?= htmlspecialchars(
        $r['district'] ?? ''
    ) ?>

</td>


<td>

    <?= htmlspecialchars(
        $r['contact'] ?? ''
    ) ?>

</td>


<td>

    <?= htmlspecialchars(
        $r['phone'] ?? ''
    ) ?>

</td>


<td>

<?= !empty(
    $r['request_date']
)
    ? date(
        'd-M-Y',
        strtotime(
            $r['request_date']
        )
    )
    : 'N/A'
?>

</td>


<td>

<?php

$requestStatus =
    trim(
        $r['status'] ??
        'Pending'
    );


if (
    $requestStatus === 'Fulfilled'
) {

    $statusClass =
        'badge-fulfilled';

} elseif (
    $requestStatus === 'Cancelled'
) {

    $statusClass =
        'badge-cancelled';

} else {

    $statusClass =
        'badge-pending';
}

?>


<span
    class="
        badge-status
        <?= $statusClass ?>
    "
>

    <?= htmlspecialchars(
        $requestStatus
    ) ?>

</span>

</td>


<td>

    <?= htmlspecialchars(
        $r['notes'] ?? ''
    ) ?>

</td>


<td>

<div class="action-column">


<a
    href="blood_bank.php?edit_request=<?= intval(
        $r['request_id']
    ) ?>&tab=requests"
    class="btn btn-warning btn-sm"
>

    Edit

</a>


<form
    method="POST"
    onsubmit="
        return confirm(
            'Are you sure you want to delete this request?'
        );
    "
>


<input
    type="hidden"
    name="action"
    value="delete_request"
>


<input
    type="hidden"
    name="request_id"
    value="<?= intval(
        $r['request_id']
    ) ?>"
>


<button
    type="submit"
    class="btn btn-danger btn-sm"
>

    Delete

</button>


</form>


</div>

</td>


</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>


<?php else: ?>

<div class="empty-state">

    No blood requests found.
    Add one using the form above.

</div>

<?php endif; ?>


<?php endif; ?>


<!-- =========================================================
     BACK
========================================================= -->

<a
    href="dashboard.php"
    class="back-link"
>

    ⬅ Back to Dashboard

</a>


</div>


<script>

/* =========================================================
   BANGLADESH DISTRICTS
========================================================= */

const districts = [

    "Bagerhat",
    "Bandarban",
    "Barguna",
    "Barishal",
    "Bhola",
    "Bogra",
    "Brahmanbaria",
    "Chandpur",
    "Chapainawabganj",
    "Chattogram",
    "Chuadanga",
    "Cox's Bazar",
    "Cumilla",
    "Dhaka",
    "Dinajpur",
    "Faridpur",
    "Feni",
    "Gaibandha",
    "Gazipur",
    "Gopalganj",
    "Habiganj",
    "Jamalpur",
    "Jashore",
    "Jhalokati",
    "Jhenaidah",
    "Joypurhat",
    "Khagrachhari",
    "Khulna",
    "Kishoreganj",
    "Kurigram",
    "Kushtia",
    "Lakshmipur",
    "Lalmonirhat",
    "Madaripur",
    "Magura",
    "Manikganj",
    "Meherpur",
    "Moulvibazar",
    "Munshiganj",
    "Mymensingh",
    "Naogaon",
    "Narail",
    "Narayanganj",
    "Narsingdi",
    "Natore",
    "Netrokona",
    "Nilphamari",
    "Noakhali",
    "Pabna",
    "Panchagarh",
    "Patuakhali",
    "Pirojpur",
    "Rajbari",
    "Rajshahi",
    "Rangamati",
    "Rangpur",
    "Satkhira",
    "Shariatpur",
    "Sherpur",
    "Sirajganj",
    "Sunamganj",
    "Sylhet",
    "Tangail",
    "Thakurgaon"

];


/* =========================================================
   DISTRICT SEARCH
========================================================= */

function filterDistricts(input) {

    const wrapper =
        input.closest(
            '.district-search-wrapper'
        );


    if (!wrapper) {
        return;
    }


    const list =
        wrapper.querySelector(
            '.district-list'
        );


    if (!list) {
        return;
    }


    const search =
        input.value
            .toLowerCase()
            .trim();


    list.innerHTML = '';


    if (!search) {

        list.style.display =
            'none';

        return;
    }


    const matched =
        districts.filter(
            function(district) {

                return district
                    .toLowerCase()
                    .includes(search);

            }
        );


    if (!matched.length) {

        list.style.display =
            'none';

        return;
    }


    matched.forEach(
        function(district) {

            const li =
                document.createElement(
                    'li'
                );


            li.textContent =
                district;


            li.addEventListener(
                'click',
                function() {

                    input.value =
                        district;

                    list.style.display =
                        'none';

                }
            );


            list.appendChild(li);

        }
    );


    list.style.display =
        'block';
}


/* =========================================================
   DISTRICT INPUT EVENT
========================================================= */

document.addEventListener(
    'input',
    function(event) {

        if (
            event.target.id ===
                'districtInput' ||

            event.target.id ===
                'districtInputReq'
        ) {

            filterDistricts(
                event.target
            );

        }

    }
);


/* =========================================================
   CLOSE DISTRICT LIST
========================================================= */

document.addEventListener(
    'click',
    function(event) {

        document
            .querySelectorAll(
                '.district-search-wrapper'
            )
            .forEach(
                function(wrapper) {

                    if (
                        !wrapper.contains(
                            event.target
                        )
                    ) {

                        const list =
                            wrapper.querySelector(
                                '.district-list'
                            );


                        if (list) {

                            list.style.display =
                                'none';

                        }

                    }

                }
            );

    }
);


/* =========================================================
   ONLY 11 DIGITS
========================================================= */

function onlyElevenDigits(input) {

    input.value =
        input.value
            .replace(
                /[^0-9]/g,
                ''
            )
            .slice(
                0,
                11
            );
}


/* =========================================================
   PHONE VALIDATION
========================================================= */

function validatePhone(
    inputId,
    errorId
) {

    const input =
        document.getElementById(
            inputId
        );


    const error =
        document.getElementById(
            errorId
        );


    if (!input || !error) {

        return true;
    }


    const value =
        input.value.trim();


    if (
        !/^[0-9]{11}$/.test(
            value
        )
    ) {

        error.classList.add(
            'show'
        );


        input.classList.remove(
            'valid'
        );


        input.classList.add(
            'invalid'
        );


        return false;
    }


    error.classList.remove(
        'show'
    );


    input.classList.remove(
        'invalid'
    );


    input.classList.add(
        'valid'
    );


    return true;
}


/* =========================================================
   DONOR FORM VALIDATION
========================================================= */

function validateDonorForm() {

    const contactValid =
        validatePhone(
            'donorContact',
            'donorContactError'
        );


    const phoneValid =
        validatePhone(
            'donorPhone',
            'donorPhoneError'
        );


    return (
        contactValid &&
        phoneValid
    );
}


/* =========================================================
   REQUEST FORM VALIDATION
========================================================= */

function validateRequestForm() {

    const contactValid =
        validatePhone(
            'requestContact',
            'requestContactError'
        );


    const phoneValid =
        validatePhone(
            'requestPhone',
            'requestPhoneError'
        );


    return (
        contactValid &&
        phoneValid
    );
}


/* =========================================================
   BLOOD GROUP FILTER
========================================================= */

function filterBloodGroup(group) {

    if (group) {

        window.location.href =
            'blood_bank.php?tab=donors&search_group=' +
            encodeURIComponent(group);

    } else {

        window.location.href =
            'blood_bank.php?tab=donors';

    }
}


/* =========================================================
   PHONE INPUT EVENTS
========================================================= */

document.addEventListener(
    'DOMContentLoaded',
    function() {

        const phoneFields = [

            'donorContact',
            'donorPhone',
            'requestContact',
            'requestPhone'

        ];


        phoneFields.forEach(
            function(id) {

                const input =
                    document.getElementById(
                        id
                    );


                if (!input) {

                    return;
                }


                input.addEventListener(
                    'input',
                    function() {

                        onlyElevenDigits(
                            this
                        );


                        validatePhone(
                            id,
                            id + 'Error'
                        );

                    }
                );


                if (
                    input.value.trim() !== ''
                ) {

                    validatePhone(
                        id,
                        id + 'Error'
                    );

                }

            }
        );

    }
);

</script>

</body>

</html>